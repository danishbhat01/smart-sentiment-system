# Technical Q&A: Pipeline Architecture & Embeddings

This document captures the engineering discussions regarding the design, safety, and optimization of the Aspect-Based Sentiment pipeline.

---

### 1. How does the Clause Splitter handle punctuation like commas and periods?
The system uses a highly conservative Regular Expression (Regex) engine that intentionally **ignores** commas and periods. It only splits text when it detects explicit contrast conjunctions (e.g., *but, however, although, whereas*). This is critical to prevent the system from accidentally fragmenting continuous thoughts (like *"the room was clean, quiet, and cool"*) into meaningless chunks. 

### 2. How did we solve the ML model missing short aspects (like "Doctor") without deteriorating performance?
We implemented an **Evidence-Based Clause Booster**. Instead of looking at the overall length of the text, the Booster loops through every individual clause. If it detects both an Aspect Keyword (e.g., "doctor") AND a Sentiment Keyword (e.g., "rude") inside the exact same clause, it safely injects the aspect. Because it requires both keywords to be present in an isolated chunk of text, it eliminates false positives.

### 3. Did the earlier system approach evaluate clauses for the Hybrid Booster?
No. In the earlier approach, the Hybrid Booster only looked at the `raw_text` as one massive string and completely ignored clauses. Furthermore, it only activated if the *entire* paragraph was under 6 words long, causing it to miss critical details in long reviews. The new approach specifically targets clauses regardless of total text length.

### 4. What if the Clause Splitter breaks the sentence incorrectly? Will it worsen the model?
The chances of the splitter worsening the model are virtually zero. We built a Graceful Fallback failsafe (`evidence = best_clause if best_clause is not None else text`). If the clause extractor breaks a sentence poorly, the system will attempt to find the aspect keyword in the broken pieces. If it cannot find it, it immediately abandons the broken clauses and falls back to evaluating the entire, original, unbroken text. 

### 5. Is that failsafe specifically hardcoded for the "Doctor" aspect?
No. The failsafe is a completely universal feature that dynamically loops over the `ASPECT_KEYWORDS` dictionary. It applies identically to all 19 hospital taxonomy categories (Cleanliness, Food Quality, Wait Time, etc.).

### 6. Can you explain the Hybrid Approach simply?
The system combines the "Brain Power" of Machine Learning with the "Strict Rules" of a Keyword Engine. 
* **The Brain (ML):** Reads the whole text to find complex meaning and context.
* **The Safety Net (Keyword Engine):** If the ML gets overwhelmed by a massive paragraph and misses a tiny detail, the keyword engine physically scans the clauses to ensure obvious complaints (like *"rude nurse"*) are never accidentally ignored.

### 7. During Batch Inference, are embeddings created again for a new raw dataset?
Yes. Because a new CSV upload contains brand-new patients writing text that the system has never seen before, the system physically wakes up the MiniLM neural network and calculates fresh embeddings from scratch.

### 8. Are those embeddings stored permanently?
No, they are stored strictly in the temporary RAM (the `EmbeddingCache`) for the duration of the session. We do this to save hard drive space. The moment the application dashboard is closed, the cache is wiped clean.

### 9. How does the system instantly fetch known texts in ~0 milliseconds?
The `EmbeddingCache` acts exactly like a digital dictionary (a Hash Map in computer science). When a sentence comes in, the computer checks the dictionary headings. If it finds the exact sentence, it just copies the numbers associated with it. Searching a Hash Map requires almost zero computational effort compared to running a neural network.

### 10. Does the Dictionary Cache work for "Partial" sentence matches?
The dictionary itself requires an exact string match. **However**, because our pipeline breaks long paragraphs into smaller clauses, we achieve a form of partial matching. If two different patients write different long reviews, but both happen to use the exact same clause (*"...but the doctor was rude"*), the system will find that shared clause in the dictionary and save time.

### 11. Are the embeddings clause-based or whole-feedback-based?
They are **both**. 
* The system calculates the embedding for the **Whole Feedback** to understand the macro-context (used by the Service Line Classifier and Aspect Detector).
* It then calculates embeddings for the **Individual Clauses** to understand micro-context (used by the Sentiment Analyzer to get isolated emotional scores).

### 12. How are both types of embeddings stored in a single dictionary?
To the digital dictionary, text length is irrelevant. It simply stores strings. A 5-paragraph essay and a 3-word clause both exist side-by-side as unique headings in the exact same list. 

### 13. Does the original dataset training script use this Cache Dictionary?
Yes, and it is the secret to our incredibly fast training times. The Service Line Classifier runs first and fills the dictionary with embeddings. When the Aspect Detector and Sentiment Analyzer models take their turn to train, they skip the heavy math and instantly copy the embeddings out of the dictionary.

### 14. What is the fundamental use of embeddings in this architecture?
Computers cannot read English words; they only understand math. Embeddings act as a universal translator. The MiniLM neural network converts the *meaning* of an English sentence into a coordinate of 384 numbers. This maps synonyms close to each other mathematically, allowing our classifiers to realize that *"The physician was excellent"* means the exact same thing as *"The doctor was great,"* even if the AI has never seen the word "physician" before.
