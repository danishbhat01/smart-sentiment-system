# System Architecture Diagram Specification

*Instructions for the Visualization Agent: Use the structured data and the Mermaid.js code block below to render or generate a high-level System Architecture Diagram for the Aspect-Based Patient Experience Intelligence system.*

## 1. Core Components

### User Interface (UI Layer)
*   **Streamlit Dashboard** (`src/dashboard/app.py`): The main frontend. Contains 4 tabs (Overview, Single Feedback, Batch Upload, Evaluation).

### Orchestration & API Layer
*   **Inference Pipeline** (`src/pipeline.py`): The central brain that orchestrates the data flow between the models, the cache, and the database.
*   **Batch Processor** (`scripts/batch_inference.py`): Handles bulk CSV processing.

### Machine Learning Layer (Models)
*   **MiniLM Embedder**: HuggingFace `all-MiniLM-L6-v2`. Converts text to 384-dimensional vectors.
*   **Service Line Classifier**: Logistic Regression (`service_line.joblib`).
*   **Aspect Detector**: One-Vs-Rest Logistic Regression predicting 19 classes (`aspect_detector.joblib`).
*   **Sentiment Analyzer**: Logistic Regression (`sentiment_model.joblib`).
*   **Theme Discoverer**: Online DBSCAN clustering for anomaly detection.

### Memory & Storage Layer
*   **EmbeddingCache**: High-speed LRU Cache in RAM (Max 5000 items).
*   **SQLite Database** (`data/database.sqlite`): Persistent storage with WAL (Write-Ahead Logging) enabled for concurrent Streamlit access.

---

## 2. Mermaid.js Architecture Diagram

```mermaid
graph TD
    %% Define Styles
    classDef ui fill:#4CAF50,stroke:#fff,stroke-width:2px,color:#fff;
    classDef logic fill:#2196F3,stroke:#fff,stroke-width:2px,color:#fff;
    classDef ml fill:#9C27B0,stroke:#fff,stroke-width:2px,color:#fff;
    classDef db fill:#FF9800,stroke:#fff,stroke-width:2px,color:#fff;
    classDef cache fill:#E91E63,stroke:#fff,stroke-width:2px,color:#fff;

    %% Nodes
    User(("User / Hospital Admin"))
    
    subgraph "Frontend Layer"
        UI["Streamlit Dashboard"]:::ui
    end

    subgraph "Core Orchestration"
        Pipeline["Inference Pipeline"]:::logic
        Batch["Batch Processor (CSV)"]:::logic
    end

    subgraph "Memory & Storage"
        Cache[("Embedding Cache (RAM)")]:::cache
        DB[("SQLite Database (WAL)")]:::db
    end

    subgraph "Machine Learning Engine"
        MiniLM["MiniLM Text Embedder"]:::ml
        SL_Model["Service Line Model (LR)"]:::ml
        Aspect_Model["Aspect Detector (OneVsRest LR)"]:::ml
        Sent_Model["Sentiment Analyzer (LR)"]:::ml
        Cluster["Online Theme Discoverer (DBSCAN)"]:::ml
    end

    %% Connections
    User -- Views/Uploads --> UI
    UI -- Triggers --> Pipeline
    UI -- Triggers --> Batch
    Batch -- Feeds Rows --> Pipeline
    
    Pipeline -- Queries/Writes --> Cache
    Cache -- Calculates Misses --> MiniLM
    
    Pipeline -- Full Embedding --> SL_Model
    Pipeline -- Full Embedding --> Aspect_Model
    Pipeline -- Clause Embedding --> Sent_Model
    Pipeline -- Unknowns --> Cluster
    
    Pipeline -- Saves Results --> DB
    UI -- Reads Metrics --> DB
```
