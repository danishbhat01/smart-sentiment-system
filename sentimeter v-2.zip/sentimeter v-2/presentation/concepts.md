# Core Concepts & Architecture Q&A

This document serves as a conceptual masterclass on the Aspect-Based Sentiment pipeline. Use these explanations to clearly articulate the complex engineering behind the system to both technical and non-technical stakeholders.

---

## Part 1: Embeddings & The Cache Dictionary

### 1. What is the fundamental use of Embeddings in this architecture?
At a fundamental level, computers cannot read English words; they only understand math. Embeddings act as a universal translator. Our MiniLM neural network converts the *meaning* of an English sentence into a coordinate list of 384 numbers. This maps synonyms close to each other mathematically, allowing our ML classifiers to realize that *"The physician was excellent"* means the exact same thing as *"The doctor was great,"* even if the AI has never been explicitly trained on the word "physician".

### 2. During Batch Inference, are embeddings created again for a new raw dataset?
Yes. When a new CSV is uploaded, it contains brand-new patient texts that the system has never seen before. Therefore, the system wakes up the MiniLM neural network and calculates fresh 384-dimensional embeddings from scratch for every new row.

### 3. Are those embeddings stored permanently?
No, they are stored strictly in the temporary RAM (inside our `EmbeddingCache`) for the duration of the session to save hard drive space. The moment the dashboard application is closed, the cache is wiped clean.

### 4. How does the system instantly fetch known texts in ~0 milliseconds?
The `EmbeddingCache` acts exactly like a digital dictionary (a Hash Map). When a sentence comes in, the computer checks the dictionary headings. If it finds the exact sentence, it bypasses the heavy neural network and just copies the 384 numbers associated with it. Searching a Hash Map requires almost zero computational effort.

### 5. Does the Dictionary Cache work for "Partial" sentence matches?
The dictionary itself requires an exact string match. **However**, because our pipeline breaks long paragraphs into smaller clauses, we achieve a powerful form of partial matching. If two different patients write different long reviews, but both happen to use the exact same clause (*"...but the doctor was rude"*), the system will find that shared clause in the dictionary and save time.

### 6. Are the embeddings clause-based or whole-feedback-based?
They are **both**. 
* The system calculates the embedding for the **Whole Feedback** to understand the macro-context (used by the Service Line and Aspect models).
* It then calculates embeddings for the **Individual Clauses** to understand micro-context (used by the Sentiment Analyzer to get isolated emotional scores).

### 7. How are both types of embeddings stored in a single dictionary?
To the digital dictionary, text length is irrelevant. It simply stores strings. A 5-paragraph essay and a 3-word clause both exist side-by-side as unique headings in the exact same list. 

### 8. Does the original dataset training script use this Cache Dictionary?
Yes, and it is the secret to our incredibly fast training times. The Service Line Classifier runs first and fills the dictionary with embeddings. When the Aspect Detector and Sentiment Analyzer models take their turn to train, they skip the heavy math and instantly copy the embeddings out of the dictionary.

---

## Part 2: The Inference Flow & Machine Learning

### 9. What is the exact execution flow during inference?
The pipeline executes in this specific order to maximize efficiency:
1. **Sentence Embedding:** Calculate and cache the embedding for the whole text.
2. **Regex Extraction:** Break the text into smaller clauses.
3. **Clause Embedding:** Calculate and cache embeddings for all clauses.
4. **Macro Prediction:** Pass the whole text embedding to the ML models to predict the Service Line and the Aspects.
5. **Clause Mapping:** Try to map the detected aspects to specific clauses using keywords.
6. **Sentiment Scoring:** Run the Sentiment Analyzer strictly on the mapped clause.

### 10. How do we predict MULTIPLE aspects using only a single sentence embedding?
We use a **One-Vs-Rest Classifier**. Behind the scenes, the code automatically builds 19 separate mini-models (one for Wait Time, one for Cleanliness, etc.). When the single 384-number embedding comes out of the cache, it gets handed to all 19 of those mini-models at the exact same time. Each model independently asks: *"Does this math contain traces of my specific category?"* Because they evaluate independently, multiple models can confidently say "Yes" at the same time.

### 11. Is the model just a Logistic Regression (LR)?
Yes. The `OneVsRestClassifier` is a wrapper that tells the computer to copy/paste the standard `LogisticRegression` algorithm from `scikit-learn` 19 times. Because Logistic Regression is based on simple linear math, running 19 of them simultaneously takes less than 1 millisecond. This gives you the incredible speed of a lightweight LR model, while allowing it to act like a complex multi-label neural network.

### *Bonus*: Why use Logistic Regression instead of a giant LLM (like GPT-4)?
Large Language Models are incredibly slow, expensive, and prone to "hallucinations" (making things up). By pairing rich Neural Network Embeddings (MiniLM) with a fast, deterministic Logistic Regression classifier, we built a system that is enterprise-grade. It is cheap to host, operates in ~30 milliseconds, and is 100% predictable, making it significantly superior for high-volume hospital operations.

---

## Part 3: The Hybrid Safety Net & Failsafes

### 12. Can you explain the Hybrid Approach simply?
The system combines the "Brain Power" of Machine Learning with the "Strict Rules" of a Keyword Engine. 
* **The Brain (ML):** Reads the whole text to find complex meaning and context.
* **The Safety Net (Keyword Engine):** We built an "Evidence-Based Clause Booster". It loops through every individual clause. If it detects both an Aspect Keyword (e.g., "doctor") AND a Sentiment Keyword (e.g., "rude") inside the exact same clause, it safely injects the aspect. This ensures obvious complaints are never accidentally ignored if the ML gets overwhelmed by a massive paragraph.

### 13. What if the Clause Splitter breaks the sentence incorrectly? Will it worsen the model?
The chances of the splitter worsening the model are virtually zero. First, the regex is highly conservative—it only splits on hard contrast words like "but" or "however," intentionally ignoring periods and commas to prevent fragmenting useful sentences. 

Second, we built a Graceful Fallback failsafe. If the clause extractor breaks a sentence poorly and the system cannot find the aspect keyword in the broken pieces, it immediately abandons the broken clauses and falls back to evaluating the entire, original, unbroken text. 

### 14. Is that failsafe specifically hardcoded for the "Doctor" aspect?
No. The failsafe is a completely universal feature that dynamically loops over the `ASPECT_KEYWORDS` dictionary. It applies identically to all 19 hospital taxonomy categories (Cleanliness, Food Quality, Wait Time, etc.).
