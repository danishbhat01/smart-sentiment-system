# Pipeline Execution Flow Diagram Specification

*Instructions for the Visualization Agent: Use the structured data and the Mermaid.js code block below to render or generate a sequential Pipeline Execution Flowchart for the Aspect-Based Sentiment Inference Engine.*

## 1. Sequence of Operations

1.  **Input**: Raw text is received (Single string).
2.  **Normalization**: Text is cleaned, lowercased, and excess whitespace is removed.
3.  **Whole-Text Embedding**: The entire text is embedded via MiniLM and cached.
4.  **Macro Classification**: The whole-text embedding is sent to the Service Line Classifier and the Aspect Detector (OneVsRest LR).
5.  **Clause Extraction**: The raw text is split into chunks using a regex targeted at contrast conjunctions (but, however, etc.).
6.  **Clause Embedding**: All extracted clauses are batch-embedded and cached.
7.  **Evidence Mapping (Hybrid Safety Net)**: The detected aspects are mapped to specific clauses using `ASPECT_KEYWORDS`. If an aspect + sentiment keyword is found, the Hybrid Booster can also inject missed aspects here.
8.  **Micro Classification (Sentiment)**: The specific mapped clause embedding is sent to the Sentiment Analyzer. (Failsafe: Falls back to whole-text embedding if mapping fails).
9.  **Routing**: The Aspect and Sentiment are routed to the correct hospital department.
10. **Anomaly Detection**: If NO aspects were found in Step 4/7, the text is routed to the Online Clusterer (DBSCAN) to discover emerging themes.

---

## 2. Mermaid.js Pipeline Flowchart

```mermaid
flowchart TD
    %% Define Styles
    classDef input fill:#607D8B,stroke:#fff,stroke-width:2px,color:#fff;
    classDef process fill:#2196F3,stroke:#fff,stroke-width:2px,color:#fff;
    classDef ml fill:#9C27B0,stroke:#fff,stroke-width:2px,color:#fff;
    classDef decision fill:#FFC107,stroke:#fff,stroke-width:2px,color:#333;
    classDef output fill:#4CAF50,stroke:#fff,stroke-width:2px,color:#fff;

    %% Nodes
    Start(["Raw Patient Feedback"]):::input
    Norm["Text Normalizer"]:::process
    
    Embed1["Calculate Whole-Text Embedding"]:::ml
    Extract["Clause Extractor (Regex)"]:::process
    Embed2["Calculate Clause Embeddings"]:::ml
    
    SL["Service Line Classifier"]:::ml
    Aspect["Aspect Detector (19 Classes)"]:::ml
    
    Map{"Map Aspects to Clauses (Keyword Engine)"}:::decision
    Sent["Sentiment Analyzer"]:::ml
    Fallback["Failsafe: Use Whole-Text"]:::process
    
    Route["Department Router"]:::process
    
    CheckAspects{"Were Aspects Detected?"}:::decision
    Cluster["Theme Discoverer (DBSCAN)"]:::ml
    
    End(["Final JSON Output / DB Save"]):::output

    %% Flow
    Start --> Norm --> Embed1
    Embed1 --> Extract --> Embed2
    
    Embed1 --> SL
    Embed1 --> Aspect
    
    Aspect --> CheckAspects
    
    CheckAspects -- "Yes" --> Map
    CheckAspects -- "No" --> Cluster
    
    Map -- "Clause Found" --> Sent
    Map -- "Clause Not Found" --> Fallback
    Fallback --> Sent
    
    Embed2 -.-> Sent
    Embed1 -.-> Fallback
    
    SL --> Route
    Sent --> Route
    
    Route --> End
    Cluster --> End
```
