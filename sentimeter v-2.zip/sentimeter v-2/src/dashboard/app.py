"""
Patient Experience Intelligence Dashboard — aspect-based view.

Each piece of feedback is broken down by aspect (e.g. doctor_explanation,
staff_politeness, wait_time) and each aspect carries its own sentiment
and department routing. There is no overall sentiment or severity — the
unit of analysis is the (aspect, sentiment) tuple.
"""
import os
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import streamlit as st
import textwrap
import sqlite3
import json
import uuid
import pandas as pd
import altair as alt
import plotly.express as px
import plotly.graph_objects as go
from io import StringIO

DB_PATH = _PROJECT_ROOT / "data" / "processed" / "patient_feedback.db"


# ============================================================
# MODERN THEME
# ============================================================
THEME_CSS = """
<style>
    :root {
        --primary: #6366f1;
        --primary-dark: #4f46e5;
        --primary-light: #818cf8;
        --success: #10b981;
        --warning: #f59e0b;
        --danger: #ef4444;
        --neutral: #6b7280;
        --bg: #0f172a;
        --bg-card: #1e293b;
        --bg-card-hover: #334155;
        --bg-input: #334155;
        --border: #475569;
        --text: #f1f5f9;
        --text-muted: #94a3b8;
    }

    .stApp {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    }

    header[data-testid="stHeader"] {
        background: rgba(15, 23, 42, 0.8);
        backdrop-filter: blur(10px);
    }

    h1, h2, h3, h4, h5, h6 {
        color: var(--text) !important;
        font-family: 'Inter', -apple-system, sans-serif;
    }

    p, label, span, div {
        color: var(--text) !important;
    }

    .stMarkdown p {
        color: var(--text) !important;
    }

    .hero-header {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #ec4899 100%);
        padding: 2.5rem 2rem;
        border-radius: 16px;
        margin-bottom: 2rem;
        box-shadow: 0 8px 32px rgba(99, 102, 241, 0.25);
        text-align: center;
    }

    .hero-header h1 {
        color: white !important;
        font-size: 2.4rem;
        font-weight: 700;
        margin: 0;
        letter-spacing: -0.02em;
    }

    .hero-header p {
        color: rgba(255, 255, 255, 0.9) !important;
        font-size: 1.05rem;
        margin-top: 0.5rem;
    }

    .section-header {
        font-size: 1.35rem;
        font-weight: 600;
        color: var(--text) !important;
        margin: 2rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid var(--primary);
        display: inline-block;
    }

    .kpi-card {
        background: var(--bg-card);
        padding: 1.4rem 1.2rem;
        border-radius: 12px;
        border: 1px solid var(--border);
        transition: all 0.25s ease;
        position: relative;
        overflow: hidden;
        min-height: 130px;
    }

    .kpi-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, var(--primary), var(--primary-light));
    }

    .kpi-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 24px rgba(99, 102, 241, 0.3);
        border-color: var(--primary);
    }

    .kpi-icon {
        font-size: 1.8rem;
        margin-bottom: 0.4rem;
    }

    .kpi-label {
        font-size: 0.8rem;
        color: var(--text-muted) !important;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-weight: 500;
        margin-bottom: 0.3rem;
    }

    .kpi-value {
        font-size: 2.1rem;
        font-weight: 700;
        color: var(--text) !important;
        line-height: 1.1;
    }

    .kpi-sub {
        font-size: 0.78rem;
        color: var(--text-muted) !important;
        margin-top: 0.3rem;
    }

    .feedback-card {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 1.1rem 1.2rem;
        margin-bottom: 0.8rem;
        transition: all 0.2s ease;
    }

    .feedback-card:hover {
        border-color: var(--primary);
        background: var(--bg-card-hover);
    }

    .feedback-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.6rem;
    }

    .feedback-id {
        font-family: 'Monaco', 'Courier New', monospace;
        font-size: 0.8rem;
        color: var(--text-muted) !important;
        background: var(--bg-input);
        padding: 0.15rem 0.5rem;
        border-radius: 4px;
    }

    .feedback-text {
        color: var(--text) !important;
        font-size: 1rem;
        line-height: 1.5;
        margin-bottom: 0.8rem;
    }

    .feedback-meta {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
        margin-top: 0.6rem;
    }

    .pill {
        display: inline-block;
        padding: 0.3rem 0.8rem;
        border-radius: 999px;
        font-size: 0.9rem;
        font-weight: 600;
        letter-spacing: 0.01em;
    }

    .pill-positive { background: rgba(16, 185, 129, 0.18); color: #34d399 !important; border: 1px solid #10b981; }
    .pill-negative { background: rgba(239, 68, 68, 0.18); color: #f87171 !important; border: 1px solid #ef4444; }
    .pill-neutral  { background: rgba(107, 114, 128, 0.18); color: #9ca3af !important; border: 1px solid #6b7280; }
    .pill-mixed    { background: rgba(245, 158, 11, 0.18); color: #fbbf24 !important; border: 1px solid #f59e0b; }
    .pill-info     { background: rgba(99, 102, 241, 0.18); color: #a5b4fc !important; border: 1px solid #6366f1; }

    .stSpinner > div {
        border-top-color: var(--primary) !important;
    }
</style>
"""


# ============================================================
# Data loading
# ============================================================
@st.cache_resource
def load_pipeline():
    from scripts._inference_utils import load_pipeline as _load
    return _load()


@st.cache_data
def load_data(db_signature: int):
    # The signature is only used to invalidate the cache when the SQLite file changes.
    if not DB_PATH.exists():
        empty = pd.DataFrame()
        return empty, empty, empty

    conn = sqlite3.connect(str(DB_PATH))
    try:
        feedbacks = pd.read_sql("SELECT * FROM feedbacks", conn)
        aspects = pd.read_sql("SELECT * FROM aspects", conn)
        themes = pd.read_sql("SELECT * FROM emerging_themes", conn)
    finally:
        conn.close()
    return feedbacks, aspects, themes


def get_db_signature() -> int:
    if not DB_PATH.exists():
        return 0
    stat = DB_PATH.stat()
    return int(stat.st_mtime_ns ^ stat.st_size)


def sentiment_pill(value: str) -> str:
    cls = {"positive": "pill-positive", "negative": "pill-negative",
           "neutral": "pill-neutral", "mixed": "pill-mixed"}.get(str(value).lower(), "pill-default")
    return f'<span class="pill {cls}">{value}</span>'


# ============================================================
# Tabs
# ============================================================
def tab_overview(feedbacks, aspects, themes):
    if feedbacks.empty:
        st.markdown(textwrap.dedent("""
        <div class="feedback-card" style="text-align:center; padding:3rem;">
            <div style="font-size:3rem;">📭</div>
            <h3>No Data Available</h3>
            <p style="color:var(--text-muted)">Run <code>python scripts/populate_db.py</code> to populate the database.</p>
        </div>
        """), unsafe_allow_html=True)
        return

    # ----- Sidebar filters -----
    with st.sidebar:
        st.markdown("### 🔍 Filters")
        depts = sorted(aspects["department"].dropna().unique())
        selected_depts = st.multiselect("Department", depts, default=[])
        aspects_list = sorted(aspects["aspect"].dropna().unique())
        selected_aspects = st.multiselect("Aspect", aspects_list, default=[])
        sls = sorted(feedbacks["service_line"].dropna().unique())
        selected_sls = st.multiselect("Service Line", sls, default=[])
        st.markdown("---")
        st.markdown("### ⚙️ Settings")
        search_text = st.text_input("Search feedback", "")

    fa = aspects.copy()
    if selected_depts:
        fa = fa[fa["department"].isin(selected_depts)]
    if selected_aspects:
        fa = fa[fa["aspect"].isin(selected_aspects)]
    if selected_sls:
        fb_filtered = feedbacks[feedbacks["service_line"].isin(selected_sls)]
        fa = fa[fa["feedback_id"].isin(fb_filtered["id"])]
    else:
        fb_filtered = feedbacks.copy()

    if search_text:
        mask = fb_filtered["raw_text"].str.contains(search_text, case=False, na=False)
        fb_filtered = fb_filtered[mask]
        fa = fa[fa["feedback_id"].isin(fb_filtered["id"])]

    # ----- KPI Cards -----
    total_feedback = len(fb_filtered)
    total_aspects = len(fa)
    unique_aspects = fa["aspect"].nunique() if not fa.empty else 0
    neg_aspects = int((fa["sentiment"] == "negative").sum())
    pos_aspects = int((fa["sentiment"] == "positive").sum())
    neg_pct = round(neg_aspects / total_aspects * 100, 1) if total_aspects else 0
    pos_pct = round(pos_aspects / total_aspects * 100, 1) if total_aspects else 0
    
    existing_themes = fb_filtered[
        (fb_filtered["emerging_theme"] != "") & 
        (~fb_filtered["emerging_theme"].str.startswith("[NEW]", na=False))
    ]["emerging_theme"].nunique()
    
    new_themes = fb_filtered[
        (fb_filtered["emerging_theme"] != "") & 
        (fb_filtered["emerging_theme"].str.startswith("[NEW]", na=False))
    ]["emerging_theme"].nunique()

    c1, c2, c3, c4, c_t1, c_t2 = st.columns(6)
    with c1:
        st.markdown(textwrap.dedent(f"""
        <div class="kpi-card">
            <div class="kpi-icon">💬</div>
            <div class="kpi-label">Total Feedback</div>
            <div class="kpi-value">{total_feedback:,}</div>
        </div>
        """), unsafe_allow_html=True)
    with c2:
        st.markdown(textwrap.dedent(f"""
        <div class="kpi-card">
            <div class="kpi-icon">🎯</div>
            <div class="kpi-label">Unique Aspects</div>
            <div class="kpi-value">{unique_aspects:,}</div>
        </div>
        """), unsafe_allow_html=True)
    with c3:
        st.markdown(textwrap.dedent(f"""
        <div class="kpi-card">
            <div class="kpi-icon">🔴</div>
            <div class="kpi-label">Negative Aspects</div>
            <div class="kpi-value">{neg_pct}%</div>
        </div>
        """), unsafe_allow_html=True)
    with c4:
        st.markdown(textwrap.dedent(f"""
        <div class="kpi-card">
            <div class="kpi-icon">🟢</div>
            <div class="kpi-label">Positive Aspects</div>
            <div class="kpi-value">{pos_pct}%</div>
        </div>
        """), unsafe_allow_html=True)
    with c_t1:
        st.markdown(textwrap.dedent(f"""
        <div class="kpi-card">
            <div class="kpi-icon">📁</div>
            <div class="kpi-label">Existing Themes</div>
            <div class="kpi-value">{existing_themes:,}</div>
        </div>
        """), unsafe_allow_html=True)
    with c_t2:
        st.markdown(textwrap.dedent(f"""
        <div class="kpi-card">
            <div class="kpi-icon">✨</div>
            <div class="kpi-label">New Themes</div>
            <div class="kpi-value">{new_themes:,}</div>
        </div>
        """), unsafe_allow_html=True)

    # ----- Row 1: Department workload + Service Line distribution -----
    st.markdown('<div class="section-header">📊 Department Workload</div>', unsafe_allow_html=True)

    c5, c6 = st.columns([3, 2])
    with c5:
        neg_dept = (
            fa[fa["sentiment"] == "negative"]
            .groupby("department").size().reset_index(name="count")
            .sort_values("count", ascending=False).head(15)
        )
        if not neg_dept.empty:
            fig = px.bar(
                neg_dept, x="count", y="department",
                orientation="h",
                color="count",
                color_continuous_scale=["#1e293b", "#6366f1", "#ec4899"],
                title=None,
            )
            fig.update_layout(
                plot_bgcolor="rgba(0,0,0,0)",
                paper_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#f1f5f9"),
                height=420,
                margin=dict(l=0, r=0, t=10, b=0),
                xaxis=dict(gridcolor="rgba(148,163,184,0.1)"),
                yaxis=dict(gridcolor="rgba(148,163,184,0.05)"),
                coloraxis_showscale=False,
            )
            st.plotly_chart(fig, use_container_width=True)
    with c6:
        sl_counts = fb_filtered["service_line"].value_counts().reset_index()
        sl_counts.columns = ["service_line", "count"]
        colors_pie = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981',
                      '#3b82f6', '#ef4444', '#06b6d4', '#84cc16']
        fig = px.pie(
            sl_counts, names="service_line", values="count",
            color_discrete_sequence=colors_pie, hole=0.55,
        )
        fig.update_layout(
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#f1f5f9"),
            height=420,
            margin=dict(l=0, r=0, t=10, b=0),
            showlegend=True,
            legend=dict(orientation="v", font=dict(size=11)),
        )
        fig.update_traces(textinfo="percent", textfont_size=12, textfont_color="white")
        st.plotly_chart(fig, use_container_width=True)

    # ----- Row 2: Aspect × Sentiment + Department × Sentiment -----
    st.markdown('<div class="section-header">🎭 Aspect × Sentiment Analysis</div>', unsafe_allow_html=True)
    c7, c8 = st.columns(2)
    with c7:
        sent_counts = fa["sentiment"].value_counts().reset_index()
        sent_counts.columns = ["sentiment", "count"]
        sent_colors = {"positive": "#10b981", "negative": "#ef4444",
                       "neutral": "#6b7280", "mixed": "#f59e0b"}
        fig2 = go.Figure(data=[
            go.Bar(
                x=sent_counts["sentiment"],
                y=sent_counts["count"],
                marker=dict(color=[sent_colors.get(s, "#6366f1") for s in sent_counts["sentiment"]]),
                text=sent_counts["count"],
                textposition="outside",
            )
        ])
        fig2.update_layout(
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#f1f5f9"),
            height=380,
            margin=dict(l=0, r=0, t=10, b=0),
            xaxis=dict(gridcolor="rgba(148,163,184,0.05)"),
            yaxis=dict(gridcolor="rgba(148,163,184,0.1)"),
            showlegend=False,
        )
        st.plotly_chart(fig2, use_container_width=True)
    with c8:
        heat = fa.groupby(["aspect", "sentiment"]).size().reset_index(name="count")
        if not heat.empty:
            heat_pivot = heat.pivot(index="aspect", columns="sentiment", values="count").fillna(0)
            fig3 = px.imshow(
                heat_pivot.values,
                x=list(heat_pivot.columns),
                y=list(heat_pivot.index),
                color_continuous_scale=["#1e293b", "#6366f1", "#ef4444"],
                aspect="auto",
                text_auto=True,
            )
            fig3.update_layout(
                plot_bgcolor="rgba(0,0,0,0)",
                paper_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#f1f5f9"),
                height=380,
                margin=dict(l=0, r=0, t=10, b=0),
            )
            st.plotly_chart(fig3, use_container_width=True)

    # ----- Row 3: Top issues + Staff workload -----
    st.markdown('<div class="section-header">🔥 Operational Insights</div>', unsafe_allow_html=True)
    c9, c10 = st.columns(2)
    with c9:
        st.markdown("**Top Negative Aspects**")
        top_neg = (fa[fa["sentiment"] == "negative"]
                   .groupby("aspect").size().reset_index(name="count")
                   .sort_values("count", ascending=False).head(10))
        if not top_neg.empty:
            st.table(top_neg.reset_index(drop=True))
    with c10:
        st.markdown("**Overall Staff Sentiment (Pos vs Neg)**")
        staff_poly = fa[fa["staff_category"] != ""]
        if not staff_poly.empty:
            staff_counts = staff_poly.groupby(["staff_category", "sentiment"]).size().reset_index(name="count")
            fig4 = px.bar(
                staff_counts, x="staff_category", y="count", color="sentiment",
                barmode="group",
                color_discrete_map={"positive": "#10b981", "negative": "#ef4444", "neutral": "#6b7280"},
            )
            fig4.update_layout(
                plot_bgcolor="rgba(0,0,0,0)",
                paper_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#f1f5f9"),
                height=350,
                margin=dict(l=0, r=0, t=10, b=0),
                xaxis=dict(gridcolor="rgba(148,163,184,0.05)", tickangle=-25),
                yaxis=dict(gridcolor="rgba(148,163,184,0.1)"),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            )
            st.plotly_chart(fig4, use_container_width=True)

    # ----- Row 4: Routing queue -----
    st.markdown('<div class="section-header">📋 Routing Queue (Top 20)</div>', unsafe_allow_html=True)
    routing = (
        fa[fa["sentiment"] == "negative"]
        .groupby(["department", "aspect"]).size()
        .reset_index(name="count")
        .sort_values("count", ascending=False).head(20)
    )
    if not routing.empty:
        st.dataframe(routing, use_container_width=True, hide_index=True)

    # ----- Row 5: Existing themes -----
    themes = fb_filtered[fb_filtered["emerging_theme"].str.strip() != ""]
    if not themes.empty:
        st.markdown('<div class="section-header">📁 Existing Themes</div>', unsafe_allow_html=True)
        theme_counts = themes.groupby("emerging_theme").size().reset_index(name="count").sort_values("count", ascending=False)
        theme_counts.columns = ["Theme Name", "Count"]
        theme_counts["Theme Name"] = theme_counts["Theme Name"].str.replace("_", " ").str.title()
        c11, c12 = st.columns([2, 1])
        with c11:
            st.dataframe(theme_counts.head(15), use_container_width=True, hide_index=True)
        with c12:
            st.metric("Total Clusters", len(theme_counts))
            st.metric("Avg Cluster Size", int(theme_counts["Count"].mean()))

    # ----- Row 6: Recent feedback browser -----
    st.markdown('<div class="section-header">🔍 Recent Feedback</div>', unsafe_allow_html=True)
    display_n = min(5, len(fb_filtered))
    if "created_at" in fb_filtered.columns:
        try:
            recent = fb_filtered.assign(
                _ts=pd.to_datetime(fb_filtered["created_at"], errors="coerce")
            ).nlargest(display_n, "_ts").drop(columns=["_ts"])
        except Exception:
            recent = fb_filtered.head(display_n)
    else:
        recent = fb_filtered.head(display_n)

    for _, row in recent.iterrows():
        fid = row.get("id", "")
        # Per-aspect pills for this feedback
        fa_row = fa[fa["feedback_id"] == fid].drop_duplicates(subset=["aspect", "sentiment"])
        aspect_pills = []
        for _, ar in fa_row.iterrows():
            asp = ar.get("aspect", "")
            sent = ar.get("sentiment", "")
            if asp:
                clean_asp = asp.replace("_", " ").title()
                clean_sent = sent.title()
                aspect_pills.append(
                    f'<span class="pill {("pill-positive" if sent=="positive" else "pill-negative" if sent=="negative" else "pill-neutral")}">'
                    f'🎯 {clean_asp} ({clean_sent})</span>'
                )
        pills_html = "".join(aspect_pills)
        sl_pill = f'<span class="pill pill-info">🏥 {row.get("service_line", "")}</span>'

        st.markdown(textwrap.dedent(f"""
        <div class="feedback-card">
            <div class="feedback-card-header">
                <span class="feedback-id">#{fid}</span>
                <span style="color:var(--text-muted); font-size:0.85rem;">{row.get("source", "")}</span>
            </div>
            <div class="feedback-text">{row.get("raw_text", "")}</div>
            <div class="feedback-meta" style="display: block;">
                <div style="margin-bottom: 0.6rem;">
                    <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.3rem; letter-spacing: 0.05em; font-weight: 600;">Service Line</div>
                    {sl_pill}
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.3rem; letter-spacing: 0.05em; font-weight: 600;">Aspect & Sentiment</div>
                    {pills_html}
                </div>
            </div>
        </div>
        """), unsafe_allow_html=True)


def tab_single_feedback():
    st.markdown('<div class="section-header">🔬 Analyze Single Feedback</div>', unsafe_allow_html=True)
    st.markdown("Enter patient feedback text to get structured aspect-based analysis.")

    samples = {
        "Multi-aspect (positive + negative)":
            "The doctor explained everything well, but the reception staff was rude and we waited almost 2 hours for billing after discharge.",
        "Surgery discharge":
            "Nurses were very caring after my surgery, but discharge took too long.",
        "App / emerging":
            "The hospital app kept crashing and I could not download my report.",
        "All positive":
            "The nurses were amazing, the doctor was thorough, and the room was spotless.",
        "All negative":
            "The wait was terrible, the staff was rude, and the billing was confusing.",
        "Single aspect":
            "The food was cold and tasteless.",
    }

    sample_choice = st.selectbox("💡 Try a sample feedback:", ["(type your own)"] + list(samples.keys()))
    if sample_choice != "(type your own)":
        default_text = samples[sample_choice]
    else:
        default_text = "The doctor explained everything well, but the reception staff was rude."

    col1, col2 = st.columns([3, 1])
    with col1:
        text = st.text_area("📝 Feedback Text", value=default_text, height=140)
    with col2:
        source = st.selectbox("📡 Source", [
            "Email", "Phone Call", "Feedback Form", "Google Review",
            "Social Media", "WhatsApp", "Post-discharge Survey", "App Feedback"
        ])
        analyze_btn = st.button("🚀 Analyze", type="primary")

    if analyze_btn and text:
        with st.spinner("Running inference..."):
            try:
                pipeline = load_pipeline()
                fid = f"FB-UI-{uuid.uuid4().hex[:8]}"
                result = pipeline.analyze(text, source=source, feedback_id=fid)
            except Exception as e:
                st.error(f"Inference failed: {e}")
                return

        # Per-aspect pill list for the header
        aspect_pills = []
        for a in result.get("aspects", []):
            cls = {"positive": "pill-positive", "negative": "pill-negative",
                   "neutral": "pill-neutral"}.get(a["sentiment"], "pill-neutral")
            clean_asp = a["aspect"].replace("_", " ").title()
            clean_sent = a["sentiment"].title()
            aspect_pills.append(f'<span class="pill {cls}">🎯 {clean_asp} ({clean_sent})</span>')
        pills_html = "".join(aspect_pills)
        sl_pill = f'<span class="pill pill-info">🏥 {result["service_line"]}</span>'

        st.markdown(
            '<div class="feedback-card">'
            '<div class="feedback-card-header">'
            f'<span class="feedback-id">{result["feedback_id"]}</span>'
            f'<span style="color:var(--text-muted); font-size:0.85rem;">{result["source"]}</span>'
            '</div>'
            f'<div class="feedback-text">{result["raw_text"]}</div>'
            '<div class="feedback-meta" style="display: block;">'
            '<div style="margin-bottom: 0.6rem;">'
            '<div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.3rem; letter-spacing: 0.05em; font-weight: 600;">Service Line</div>'
            f'{sl_pill}'
            '</div>'
            '<div>'
            '<div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.3rem; letter-spacing: 0.05em; font-weight: 600;">Aspect & Sentiment</div>'
            f'{pills_html}'
            '</div>'
            '</div></div>', unsafe_allow_html=True)

        # Routing
        if result.get("routing"):
            routing_pills = "".join([
                f'<span class="pill pill-info">{dept}</span>'
                for dept in result["routing"]
            ])
            st.markdown(
                '<div style="margin: 1rem 0;">'
                '<div class="kpi-label">📍 Routing Queue</div>'
                f'<div style="margin-top:0.5rem;">{routing_pills}</div>'
                '</div>', unsafe_allow_html=True)

        # Aspects table
        if result.get("aspects"):
            st.markdown('<div class="section-header">🎯 Detected Aspects</div>', unsafe_allow_html=True)
            rows = []
            for a in result["aspects"]:
                rows.append({
                    "Aspect": a["aspect"],
                    "Sentiment": a["sentiment"],
                    "Confidence": f"{a['confidence']:.1%}",
                    "Department": a["department"],
                    "Staff": a.get("staff_category", "—") or "—",
                    "Evidence": a["evidence"],
                })
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        else:
            st.info("No aspects detected for this feedback.")

        # Clauses
        if result.get("clauses") and len(result["clauses"]) > 1:
            with st.expander("📝 View Detected Clauses"):
                for i, c in enumerate(result["clauses"], 1):
                    st.markdown(f"**Clause {i}:** {c['text']}")
                    st.markdown(f"_{c['aspect'] or '—'} → {c['sentiment']}_")
                    st.markdown("---")

        # Full JSON
        with st.expander("🔍 View Full JSON Output"):
            st.json(result)


def tab_csv_upload():
    st.markdown('<div class="section-header">📤 Batch Inference</div>', unsafe_allow_html=True)
    st.markdown("Upload a CSV with patient feedback for batch analysis. Expected columns: `text`, `feedback`, or `Feedback Text`.")

    uploaded = st.file_uploader("📂 Choose CSV file", type=["csv"])
    if uploaded is not None:
        try:
            df = pd.read_csv(uploaded)
        except Exception as e:
            st.error(f"Failed to read CSV: {e}")
            return

        st.markdown(textwrap.dedent(f"""
        <div class="feedback-card">
            <div class="kpi-label">📊 Preview</div>
            <div style="color:var(--text); margin-top:0.5rem;">Loaded <strong>{len(df)}</strong> rows · <strong>{len(df.columns)}</strong> columns</div>
        </div>
        """), unsafe_allow_html=True)
        st.dataframe(df.head(5), use_container_width=True)

        text_col = None
        for col in ["text", "feedback", "feedback_text", "Feedback Text", "comment", "message"]:
            if col in df.columns:
                text_col = col
                break

        if not text_col:
            st.error("No text column found. Need one of: text, feedback, feedback_text, Feedback Text, comment, message")
            return

        st.success(f"✓ Using text column: **{text_col}**")

        col1, col2, col3 = st.columns(3)
        with col1:
            source = st.text_input("Default source", "Batch Upload")
        with col2:
            output_fmt = st.selectbox("Output format", ["csv", "json"])
        with col3:
            st.markdown("<br/>", unsafe_allow_html=True)
            run_btn = st.button("🚀 Run Inference", type="primary")

        if run_btn:
            pipeline = load_pipeline()
            results = []
            progress = st.progress(0)
            status = st.empty()
            for i, text in enumerate(df[text_col].astype(str).tolist()):
                fid = f"FB-UP-{uuid.uuid4().hex[:8]}"
                try:
                    result = pipeline.analyze(text, source=source, feedback_id=fid)
                except Exception:
                    result = {
                        "feedback_id": fid, "source": source, "raw_text": text,
                        "service_line": "Error", "service_confidence": 0.0,
                        "aspects": [], "routing": [], "clauses": [],
                        "known_category_match": True, "emerging_theme": "",
                    }
                results.append(result)
                progress.progress((i + 1) / len(df))
                status.text(f"Processed {i + 1}/{len(df)}")
            progress.empty()
            status.empty()

            # --- ONLINE CLUSTERER ---
            anomalies = []
            for r in results:
                if not r.get("known_category_match", True) and not r.get("emerging_theme"):
                    anomalies.append(r["raw_text"])

            if anomalies:
                from src.clustering.online_clusterer import OnlineClusterer
                clusterer = OnlineClusterer()
                new_themes_dict = clusterer.discover_new_themes(anomalies, pipeline.cache)
                for r in results:
                    text = r.get("raw_text", "")
                    if text in new_themes_dict and new_themes_dict[text]:
                        r["emerging_theme"] = new_themes_dict[text]

            st.success(f"✓ Processed **{len(results)}** rows")

            # Summary stats
            total_count = len(results)
            avg_aspects = round(sum(len(r.get("aspects", [])) for r in results) / max(total_count, 1), 2)
            neg_count = sum(1 for r in results for a in r.get("aspects", []) if a.get("sentiment") == "negative")
            pos_count = sum(1 for r in results for a in r.get("aspects", []) if a.get("sentiment") == "positive")
            existing_themes = len(set(r["emerging_theme"] for r in results if r.get("emerging_theme") and not str(r["emerging_theme"]).startswith("[NEW]")))
            new_themes = len(set(r["emerging_theme"] for r in results if r.get("emerging_theme") and str(r["emerging_theme"]).startswith("[NEW]")))

            s1, s2, s3, s4, s5, s6 = st.columns(6)
            with s1:
                st.markdown(textwrap.dedent(f"""
                <div class="kpi-card">
                    <div class="kpi-icon">💬</div>
                    <div class="kpi-label">Total</div>
                    <div class="kpi-value">{total_count:,}</div>
                </div>
                """), unsafe_allow_html=True)
            with s2:
                st.markdown(textwrap.dedent(f"""
                <div class="kpi-card">
                    <div class="kpi-icon">📊</div>
                    <div class="kpi-label">Avg Aspects</div>
                    <div class="kpi-value">{avg_aspects}</div>
                </div>
                """), unsafe_allow_html=True)
            with s3:
                st.markdown(textwrap.dedent(f"""
                <div class="kpi-card">
                    <div class="kpi-icon">🔴</div>
                    <div class="kpi-label">Negative</div>
                    <div class="kpi-value">{neg_count:,}</div>
                </div>
                """), unsafe_allow_html=True)
            with s4:
                st.markdown(textwrap.dedent(f"""
                <div class="kpi-card">
                    <div class="kpi-icon">🟢</div>
                    <div class="kpi-label">Positive</div>
                    <div class="kpi-value">{pos_count:,}</div>
                </div>
                """), unsafe_allow_html=True)
            with s5:
                st.markdown(textwrap.dedent(f"""
                <div class="kpi-card">
                    <div class="kpi-icon">📁</div>
                    <div class="kpi-label">Existing Themes</div>
                    <div class="kpi-value">{existing_themes:,}</div>
                </div>
                """), unsafe_allow_html=True)
            with s6:
                st.markdown(textwrap.dedent(f"""
                <div class="kpi-card">
                    <div class="kpi-icon">✨</div>
                    <div class="kpi-label">New Themes</div>
                    <div class="kpi-value">{new_themes:,}</div>
                </div>
                """), unsafe_allow_html=True)

            # ----- Batch Operational Insights -----
            st.markdown('<div class="section-header">🔥 Batch Operational Insights</div>', unsafe_allow_html=True)
            bc1, bc2 = st.columns(2)
            
            with bc1:
                st.markdown("**Service Line Distribution**")
                sl_counts = pd.Series([r.get("service_line") for r in results if r.get("service_line")]).value_counts()
                if not sl_counts.empty:
                    st.dataframe(sl_counts.reset_index(), use_container_width=True, hide_index=True)
                
            with bc2:
                st.markdown("**Overall Staff Sentiment (Pos vs Neg)**")
                staff_poly = [
                    {"staff_category": a.get("staff_category"), "sentiment": a.get("sentiment")}
                    for r in results 
                    for a in r.get("aspects", []) 
                    if a.get("staff_category")
                ]
                if staff_poly:
                    staff_df = pd.DataFrame(staff_poly)
                    staff_counts = staff_df.groupby(["staff_category", "sentiment"]).size().reset_index(name="count")
                    fig = px.bar(
                        staff_counts, x="staff_category", y="count", color="sentiment",
                        barmode="group",
                        color_discrete_map={"positive": "#10b981", "negative": "#ef4444", "neutral": "#6b7280"},
                    )
                    fig.update_layout(
                        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
                        font=dict(color="#f1f5f9"), height=280, margin=dict(l=0, r=0, t=10, b=0),
                        xaxis=dict(gridcolor="rgba(148,163,184,0.05)", tickangle=-25),
                        yaxis=dict(gridcolor="rgba(148,163,184,0.1)"),
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                    )
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("No staff politeness mentions detected in this batch.")
            # Build flat CSV
            flat_rows = []
            for r in results:
                base = {
                    "feedback_id": r.get("feedback_id", ""),
                    "source": r.get("source", ""),
                    "raw_text": r.get("raw_text", ""),
                    "service_line": r.get("service_line", ""),
                    "service_confidence": r.get("service_confidence", 0),
                    "routing": "|".join(r.get("routing", [])),
                    "num_aspects": len(r.get("aspects", [])),
                    "emerging_theme": r.get("emerging_theme", ""),
                }
                for asp in r.get("aspects", []):
                    row = dict(base)
                    row.update({
                        "aspect": asp["aspect"],
                        "aspect_sentiment": asp["sentiment"],
                        "aspect_confidence": asp["confidence"],
                        "evidence": asp["evidence"],
                        "staff_category": asp.get("staff_category", ""),
                        "department": asp["department"],
                    })
                    flat_rows.append(row)
                if not r.get("aspects"):
                    flat_rows.append(base)

            result_df = pd.DataFrame(flat_rows)
            st.markdown("**Preview (first 20 rows):**")
            st.dataframe(result_df.head(20), use_container_width=True)

            csv_buf = StringIO()
            result_df.to_csv(csv_buf, index=False)
            st.download_button(
                "📥 Download CSV",
                csv_buf.getvalue(),
                file_name="batch_predictions.csv",
                mime="text/csv",
            )

            json_buf = json.dumps(results, indent=2)
            st.download_button(
                "📥 Download JSON",
                json_buf,
                file_name="batch_predictions.json",
                mime="application/json",
            )


def tab_evaluation():
    st.markdown('<div class="section-header">📈 Model Performance</div>', unsafe_allow_html=True)
    st.markdown("Run the evaluation script to see detailed performance metrics on a held-out test set.")

    if st.button("🚀 Run Full Evaluation", type="primary"):
        with st.spinner("Evaluating models... this may take a moment..."):
            import subprocess
            result = subprocess.run(
                ["python", "scripts/evaluate.py"],
                capture_output=True, text=True, timeout=300, cwd=".",
            )
            st.markdown("### Output")
            st.code(result.stdout, language="text")
            if result.returncode != 0:
                st.error(f"Evaluation failed:\n{result.stderr}")
            elif result.stderr:
                st.warning(f"Stderr:\n{result.stderr}")


# ============================================================
# Main
# ============================================================
st.set_page_config(
    page_title="SentiMeter - Patient Experience Intelligence",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(THEME_CSS, unsafe_allow_html=True)

st.markdown(textwrap.dedent("""
<div class="hero-header">
    <h1 style="font-size: 3.2rem; font-weight: 800; letter-spacing: -0.04em; margin-bottom: 0.2rem;">
        <span style="color: #ffffff;">Senti</span><span style="color: #34d399;">Meter</span><span style="font-size: 1.5rem; vertical-align: super; color: rgba(255,255,255,0.7);">™</span>
    </h1>
    <p style="font-size: 1.15rem; font-weight: 500; letter-spacing: 0.02em;">Hospital Patient Experience Intelligence</p>
</div>
"""), unsafe_allow_html=True)

tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Dashboard",
    "🔬 Single Feedback",
    "📤 Batch Upload",
    "📈 Evaluation",
])

with tab1:
    try:
        feedbacks, aspects, themes = load_data(get_db_signature())
        tab_overview(feedbacks, aspects, themes)
    except Exception as e:
        st.error(f"Could not load data: {e}")

with tab2:
    tab_single_feedback()

with tab3:
    tab_csv_upload()

with tab4:
    tab_evaluation()

st.markdown("---")
st.markdown(textwrap.dedent("""
<div style="text-align:center; padding:1rem; color:var(--text-muted); font-size:0.85rem;">
    Patient Experience Intelligence Platform · Built with Streamlit · v1.0
</div>
"""), unsafe_allow_html=True)
