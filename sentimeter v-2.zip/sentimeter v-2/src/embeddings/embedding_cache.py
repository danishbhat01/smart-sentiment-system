"""
Bounded LRU embedding cache.

The cache is keyed by raw text strings and stores their 384-D MiniLM
embeddings as numpy arrays. The cache uses an OrderedDict to provide
LRU semantics: least-recently-used entries are evicted when the cache
exceeds `max_size`.

Why bounded:
- A naive `dict` grows without bound in long-running services, eventually
  triggering OOM crashes.
- 5000 entries × 384 floats × 8 bytes ≈ 15 MB — predictable memory.
- Cache hits remain O(1); cache misses trigger a MiniLM forward pass.
"""
from collections import OrderedDict
import numpy as np

from src.embeddings.embedder import Embedder


class EmbeddingCache:
    def __init__(self, embedder: Embedder = None, max_size: int = 5000):
        self.embedder = embedder or Embedder()
        self._cache: "OrderedDict[str, np.ndarray]" = OrderedDict()
        self.max_size = max_size

    def encode(self, text: str) -> np.ndarray:
        if text not in self._cache:
            vec = self.embedder.encode(text)
            arr = np.asarray(vec)
            if arr.ndim == 2:
                arr = arr[0]
            self._cache[text] = arr
            if len(self._cache) > self.max_size:
                self._cache.popitem(last=False)  # evict oldest (LRU)
        else:
            self._cache.move_to_end(text)  # mark as recently used
        return self._cache[text]

    def encode_and_store(self, texts) -> np.ndarray:
        results = []
        uncached = []
        uncached_indices = []
        
        for i, t in enumerate(texts):
            if t in self._cache:
                self._cache.move_to_end(t)  # Protect from eviction by making it MRU
                results.append(self._cache[t])
            else:
                uncached.append(t)
                uncached_indices.append(i)
                results.append(None) # Placeholder
                
        if uncached:
            new_vecs = self.embedder.encode(uncached)
            arr = np.asarray(new_vecs)
            if arr.ndim == 3:
                arr = arr[0]
            elif arr.ndim == 1:
                arr = arr.reshape(1, -1)
                
            for t, emb, idx in zip(uncached, arr, uncached_indices):
                results[idx] = emb
                self._cache[t] = emb
                if len(self._cache) > self.max_size:
                    self._cache.popitem(last=False)
                    
        stacked = np.array(results)
        if stacked.ndim == 3:
            stacked = stacked.reshape(len(texts), -1)
        if stacked.ndim == 1:
            stacked = stacked.reshape(1, -1)
        return stacked

    def clear(self):
        self._cache.clear()

    def stats(self) -> dict:
        return {"size": len(self._cache), "max_size": self.max_size}