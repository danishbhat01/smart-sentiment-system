# Sentimeter V-2: Aspect-Based Customer Feedback Intelligence

## Why We Built It
Hospitals and healthcare organizations receive massive volumes of patient feedback daily. Processing this feedback manually is impossible, and relying on Large Language Models (LLMs) like GPT-4 can be incredibly slow, expensive, and prone to "hallucinations." 

We built **Sentimeter V-2** to provide an enterprise-grade, fast, and 100% deterministic pipeline for analyzing hospital patient feedback. By pairing rich Neural Network Embeddings (MiniLM) with lightweight, lightning-fast Logistic Regression classifiers, we created a system that is cheap to host, operates in ~30 milliseconds, and accurately extracts service lines, aspects, and sentiments from patient reviews.

---

## Technical Approaches & Architecture

### 1. Hybrid Intelligence System
Sentimeter V-2 uses a powerful hybrid approach, combining Machine Learning with a Keyword Engine:
* **The Brain (ML):** Reads the whole text to understand complex meaning, nuance, and context.
* **The Safety Net (Keyword Engine):** An "Evidence-Based Clause Booster" loops through every individual clause. If it detects an Aspect Keyword (e.g., "doctor") AND a Sentiment Keyword (e.g., "rude") inside the exact same clause, it safely injects the aspect. This ensures obvious complaints are never ignored, even if the ML gets overwhelmed by a massive paragraph.

### 2. Embeddings & The Cache Dictionary
At the core of our system is the MiniLM neural network, which converts English sentences into a 384-dimensional coordinate list (embeddings). This allows our models to group synonyms mathematically without explicit keyword training.
* **Zero-Latency Cache:** To maximize speed, we store calculated embeddings in a strictly temporary `EmbeddingCache` (a Hash Map) in RAM. When identical sentences or clauses are processed, the system bypasses the neural network and fetches the embeddings in ~0 milliseconds.

### 3. Clause-Based & Full Sentence Embeddings
We utilize a dual-embedding strategy to capture both macro and micro contexts:
* **Full Feedback Embedding:** The system calculates embeddings for the entire text to grasp the macro-context, which is used to predict the broader Service Line and Aspects.
* **Clause-Based Embedding:** Long paragraphs are conservatively broken down into smaller clauses using contrast words (e.g., "but", "however"). The system calculates embeddings for these isolated clauses to understand the micro-context, ensuring sentiment scores are highly accurate and focused.

### 4. *New Approach:* Nearest Sentiment with Sentence Level Embedding
When using sentence-level embeddings, we introduced an innovative approach: **Nearest Sentiment mapping**. Instead of just applying a broad sentiment over the whole text, the system calculates the nearest emotional sentiment specific to the detected aspect. By using sentence-level embeddings to find the semantic proximity between the aspect and surrounding sentiment indicators, the model guarantees that multi-aspect reviews are accurately partitioned (e.g., scoring "cleanliness" as positive, while correctly identifying "wait time" as negative).

### 5. Multi-Label Classification via One-Vs-Rest
To predict multiple aspects simultaneously from a single sentence embedding, we utilize a **One-Vs-Rest Classifier**. The system automatically runs 19 separate Logistic Regression models (one for each category like Wait Time, Cleanliness, etc.) in parallel. Since Logistic Regression uses simple linear math, running 19 models simultaneously takes less than 1 millisecond, granting neural-network-like capabilities at maximum speed.

---

## Pipeline Execution Flow
The inference pipeline executes in a strict, optimized order:
1. **Sentence Embedding:** Calculate and cache the embedding for the whole text.
2. **Regex Extraction:** Break the text into smaller clauses safely using contrast words.
3. **Clause Embedding:** Calculate and cache embeddings for all resulting clauses.
4. **Macro Prediction:** Pass the whole text embedding to the One-Vs-Rest models to predict the Service Line and Aspects.
5. **Clause Mapping:** Try to map the detected aspects to specific clauses using keywords and context.
6. **Sentiment Scoring & Nearest Sentiment:** Run the Sentiment Analyzer strictly on the mapped clause, leveraging the nearest sentiment approach for sentence-level context.

---

## Setup Steps

Follow these steps to run the Sentimeter V-2 project locally:

1. **Navigate to the project directory:**
   Ensure you are in the `sentimeter v-2` folder.
   ```bash
   cd "sentimeter v-2"
   ```

2. **Create a Virtual Environment:**
   It is recommended to use a virtual environment to manage dependencies.
   ```bash
   python -m venv venv
   ```

3. **Activate the Virtual Environment:**
   * **Windows:**
     ```bash
     venv\Scripts\activate
     ```
   * **Mac/Linux:**
     ```bash
     source venv/bin/activate
     ```

4. **Install Requirements:**
   Install all the necessary Python libraries required for ML, NLP, and the Dashboard.
   ```bash
   pip install -r requirements.txt
   ```

5. **Run the Dashboard (Optional UI):**
   Launch the Streamlit web application.
   ```bash
   streamlit run src/dashboard/app.py
   ```

6. **Run the Main Pipeline:**
   Alternatively, you can run the main Python script to test the backend processing.
   ```bash
   python main.py
   ```
