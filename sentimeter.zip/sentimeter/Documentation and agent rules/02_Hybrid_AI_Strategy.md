# 2. Our Approach: The Hybrid AI Strategy (Tech & Business)

When designing this system, we intentionally avoided "hype-driven" development (like throwing a massive, slow LLM at the problem). Instead, we built a **Pragmatic Hybrid Architecture** designed specifically for high-speed, enterprise-grade production.

## What is a Hybrid AI Architecture?
A Hybrid AI Architecture means we use advanced Machine Learning (ML) where the data is complex and nuanced, but we use hard-coded, deterministic "Rules" where safety and precision are paramount.

### Example 1: The "Hybrid Short-Text Booster"
* **The Problem:** ML models are great at understanding long paragraphs, but they often struggle to classify very short, punchy feedback (e.g., "Rude nurse. Dirty room.").
* **Our Solution:** We implemented a Hybrid Keyword Booster. The system first runs the text through the ML model. If the text is very short (under 6 words) and the ML model isn't confident, our system activates a secondary rule-based engine. This engine scans for high-signal keywords ("rude", "dirty") and explicitly injects the correct classification.
* **Business Impact:** We achieve 98% accuracy on aspect detection because our ML engine handles the nuance, while our rule-engine ensures we never miss the obvious, critical short complaints.

### Example 2: Clause Extraction vs. Sentiment Dilution
* **The Problem:** A patient says: *"The doctor was a lifesaver, but the waiting room was filthy."* If you feed this into a standard sentiment AI, the "lifesaver" and "filthy" cancel each other out, resulting in a useless "Neutral" score.
* **Our Solution:** Before running the Sentiment AI, we run a "Clause Extractor." This uses syntactic rules (looking for contrast words like "but" or "however") to physically slice the sentence in half. We then run the AI on the *isolated pieces* of evidence.
* **Business Impact:** The Medical Director sees a 100% Positive score for the Doctor, and Facilities sees a 100% Negative score for the Waiting Room. No diluted data.

### Example 3: Caching for Real-Time Execution
* **The Problem:** Processing AI embeddings is computationally expensive and slow.
* **Our Solution:** We built an LRU (Least Recently Used) `EmbeddingCache`. When a feedback is processed, its complex mathematical representation is cached in memory. If that text (or pieces of it) need to be evaluated by multiple different models (Service Line, Aspect, Sentiment), it never has to be re-calculated.
* **Business Impact:** Inference latency dropped from 20+ seconds down to **~35 milliseconds**. The system runs in real-time.
