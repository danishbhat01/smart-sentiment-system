# Architecture

Hospital patient feedback **Aspect-Based Sentiment Analysis (ABSA)** pipeline. Non-LLM approach using Logistic Regression + MiniLM embeddings on a 5000-row synthetic hospital feedback dataset (715 unique texts).

## Data Flow

```
CSV (5000 rows)
  ↓ python main.py                       # train
Models (4 .joblib)
  ↓ python scripts/populate_db.py        # run inference, persist
SQLite (5000 feedbacks, ~7000 aspects)
  ↓ streamlit run src/dashboard/app.py
Dashboard (4 tabs: Overview, Single Feedback, Batch Upload, Evaluation)
```

## Inference Pipeline

The single entry point is `InferencePipeline.analyze(text)` in `src/pipeline.py`. It runs these stages:

1. **Normalize** — whitespace collapse (`src/preprocessing/normalizer.py`)
2. **Encode** full text once → 384-dim MiniLM vector (LRU-cached in `src/embeddings/embedding_cache.py`, max 5000 entries ≈ 15 MB)
3. **Extract clauses** — regex split on `but/however/and/.` (`src/clause_extraction/clause_extractor.py`)
4. **Predict aspects** on full-text embedding via `OneVsRestClassifier(LogisticRegression)` over 19 classes, threshold 0.50 (`src/aspect_detection/classifier.py`)
5. **Hybrid short-text booster** for inputs <6 tokens — keyword gate fallback that uses `ASPECT_KEYWORDS` to inject aspects the LR missed (`src/pipeline.py:107`)
6. **Map aspects → clauses** by `aspect_matches_clause(aspect, clause)` for per-aspect evidence (`src/aspect_detection/keyword_gate.py`)
7. **Predict sentiment** per matched clause via binary `LogisticRegression` + keyword override (`src/sentiment/analyzer.py`)
8. **Staff classifier** — pure rule-based keyword matching (`src/staff_classifier/`)
9. **Route** to hospital department via `ASPECT_DEPARTMENT_MAP` + `STAFF_TOKEN_TO_DEPARTMENT` (`src/routing/router.py`)
10. **Theme fallback** — if no aspects detected, run `theme_discoverer.discover()` which uses cosine similarity on 384-D cluster centroids (`src/clustering/theme_discoverer.py`)

The output is a list of per-aspect records: `{aspect, sentiment, confidence, evidence, staff_category, department}`. There is intentionally **no overall sentiment or overall severity** — the unit of analysis is the per-aspect tuple.

## Components

| File | Role |
|------|------|
| `src/embeddings/embedder.py` | MiniLM wrapper (`all-MiniLM-L6-v2`, class-level singleton) |
| `src/embeddings/embedding_cache.py` | LRU cache (`OrderedDict`, `max_size=5000`, `move_to_end` on hit) |
| `src/preprocessing/normalizer.py` | Whitespace cleanup |
| `src/clause_extraction/clause_extractor.py` | Regex split on contrast conjunctions |
| `src/aspect_detection/classifier.py` | `OneVsRestClassifier(LogisticRegression)` over 19 hospital aspects |
| `src/aspect_detection/keyword_gate.py` | `aspect_matches_clause()` + `ASPECT_KEYWORDS` |
| `src/sentiment/analyzer.py` | Binary LR + keyword override (positive/negative) |
| `src/service_line/classifier.py` | LR + keyword boost (3 confidence bands) |
| `src/staff_classifier/classifier.py` | Pure rule-based (12 staff categories) |
| `src/clustering/theme_discoverer.py` | DBSCAN clustering + 384-D cosine centroid assignment |
| `src/clustering/online_clusterer.py` | Online DBSCAN for anomalies from the dashboard's batch upload |
| `src/routing/router.py` | Aspect/staff → department mapping |
| `src/database/connection.py` | SQLite (WAL mode) + `BatchInserter` (batched commits) |
| `src/pipeline.py` | Orchestrator — the only entry point for inference |
| `src/dashboard/app.py` | Streamlit UI (4 tabs) |
| `main.py` | Training entry point |
| `scripts/populate_db.py` | Run inference on all 5000 rows, write to SQLite |
| `scripts/evaluate.py` | Model metrics on a held-out test split |
| `scripts/analyze.py` | Single-feedback CLI |
| `scripts/batch_inference.py` | CSV → JSON/CSV batch CLI |
| `scripts/_inference_utils.py` | Shared `load_pipeline()` helper |

## Why These Choices

- **Logistic Regression + MiniLM (not deep nets):** 715 unique training texts is too small to fine-tune a transformer. LR over MiniLM embeddings gets 80%+ sentiment accuracy and 98% aspect micro-F1 with deterministic inference.
- **`OneVsRestClassifier` for multi-label aspects:** each aspect is independent; the model doesn't need to learn correlations between aspects.
- **UMAP at training time, cosine at inference:** `UMAP.transform()` on a single point is 12–20 seconds. Cosine similarity on 384-D centroids is sub-millisecond and mathematically correct for normalized embeddings.
- **Hybrid ML + rules** (sentiment, service line, short-text booster): ML handles semantic cases; rules catch obvious ones like "rude" → negative.
- **Bounded LRU cache (`max_size=5000`):** long-running services can't grow memory unbounded.
- **Per-aspect output** (no overall_sentiment/overall_severity): the dataset's `Aspect Sentiments` column is per-aspect, and the output honors that structure.

## Data Layout

```
configs/config.yaml          # paths, model name, classifier thresholds, lists of categories
data/                        # raw CSV (input)
models/                      # serialized classifiers (output of training)
data/database.sqlite                 # SQLite (output of populate)
```

SQLite schema (`src/database/connection.py`):
- `feedbacks` — one row per feedback (id, raw_text, service_line, departments_involved, etc.)
- `aspects` — one row per (feedback, aspect) tuple with sentiment, evidence, staff_category, department
- `clauses` — one row per (feedback, clause) with attached aspect/sentiment
- `emerging_themes` — cluster summaries from the theme discoverer

## Operational Runbook

| Task | Command |
|------|---------|
| Train all models | `python main.py` |
| Populate the database | `python scripts/populate_db.py` |
| Evaluate on the held-out test split | `python scripts/evaluate.py` |
| Run live feedback evaluation (15 cases) | `python run_live_feedbacks.py` |
| Single-feedback smoke test | `python test_inference.py` |
| New-feedback smoke test | `python test_new_feedbacks.py` |
| Single feedback from CLI | `python scripts/analyze.py "text here"` |
| CSV → JSON/CSV inference | `python scripts/batch_inference.py --input in.csv --output out.json` |
| Launch the dashboard | `streamlit run src/dashboard/app.py` |

## Performance Snapshot

- Inference latency: ~30 ms warm, ~150 ms cold (MiniLM first call)
- Theme discoverer (novel feedback): <1 ms
- Populate 5000 rows: ~30 s (vs ~85 min before the UMAP→cosine refactor)
- Sentiment accuracy: 80% (up from 73% after the clause-level training fix)
- Service-line accuracy: 95% on unique-text holdout