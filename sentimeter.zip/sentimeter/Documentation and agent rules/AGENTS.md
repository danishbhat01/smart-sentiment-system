# AGENTS.md

Conventions and lessons learned for working on this codebase. Read this before making changes.

## Project Overview

Hospital patient feedback **Aspect-Based Sentiment Analysis (ABSA)** pipeline. Non-LLM approach: Logistic Regression + MiniLM embeddings over a 5000-row synthetic dataset (715 unique texts). See `ARCHITECTURE.md` for the data flow and component catalog.

## Workflow Conventions

| Task | Command |
|------|---------|
| Train all models | `python main.py` |
| Populate the database | `python scripts/populate_db.py` |
| Evaluate on the held-out test split | `python scripts/evaluate.py` |
| Run live feedback evaluation | `python run_live_feedbacks.py` |
| Single-feedback smoke test | `python test_inference.py` |
| New-feedback smoke test | `python test_new_feedbacks.py` |
| Launch the dashboard | `streamlit run src/dashboard/app.py` |

All scripts assume the project root is the working directory.

## Code Conventions

### Classifiers expose `predict_with_embedding(...)`

Every classifier that consumes MiniLM vectors exposes a `predict_with_embedding(embedding, text)` API. The pipeline encodes the full text **once** and threads the resulting 384-D vector through each classifier. If you add a new classifier, follow the same pattern — never call `self.cache.encode(text)` inside the classifier's `predict()` method (that defeats the encode-once optimization).

### ML classifiers embed once, rules run inline

MiniLM encoding is the dominant inference cost. Batch-encode all inputs once at the start of `analyze()` (see `src/pipeline.py:80-87`). Rule-based components (staff classifier, router) run inline without embedding.

### Dedup at training time, not inference time

Aspect detection and sentiment training both deduplicate the input by text before `train_test_split` (`src/aspect_detection/classifier.py:38-46`, `src/sentiment/analyzer.py:47-55`). Without this, identical rows leak from train into test and inflate accuracy.

### Train and infer on the same distribution

Aspect is trained on full feedback texts and predicted on full-text embeddings. Sentiment is trained on **clauses** (extracted via `ClauseExtractor`) and predicted on clause embeddings. The mismatch between these was a real bug — it cost 7 percentage points on sentiment accuracy before it was fixed.

### Bounded resources

- The embedding cache uses an LRU with `max_size=5000` (`src/embeddings/embedding_cache.py`). Don't replace it with an unbounded dict.
- The aspect space is fixed at 19 categories. Don't introduce open-vocabulary aspect extraction.
- `theme_discoverer.min_similarity=0.5` is the threshold for "known" vs "unknown" feedback. Don't lower it without retraining.

### Output schema is per-aspect

The pipeline does **not** produce `overall_sentiment` or `overall_severity`. Each detected aspect carries its own sentiment, evidence, and department. Don't reintroduce aggregate fields — the dashboard, database schema, and tests all assume per-aspect output.

## Known Patterns

### Short-text fallback

For inputs with fewer than 6 tokens, the pipeline runs a keyword-based booster (`src/pipeline.py:107`) that injects aspects from `ASPECT_KEYWORDS` (`src/aspect_detection/keyword_gate.py`) with synthetic 0.90 confidence. This is by design — LR on 3-word inputs is unreliable. If you change this, also retrain the model and re-run `test_new_feedbacks.py`.

### Theme fallback

When aspect detection returns zero aspects, the pipeline runs `theme_discoverer.discover()` which uses cosine similarity against precomputed 384-D cluster centroids. `known_category_match` is `True` only when aspects fired or a theme was matched (`src/pipeline.py:210`).

### Aspect → clause evidence

After aspect detection, each detected aspect is matched to the clause whose text contains the aspect's discriminative keyword (`aspect_matches_clause`). Sentiment is then predicted on that matched clause, not the full text. This preserves per-aspect sentiment polarity on multi-clause feedback like "Doctor was good but nurse was bad."

## Multi-Agent Considerations

Multiple agents may work on this codebase simultaneously (different sessions, different tools). Before modifying any file:

1. **Re-read the current state of the file.** Don't trust your mental model from a previous session — files may have been edited or deleted.
2. **Check for `_inference_utils.py` import patterns.** The script-level `sys.path.append` works in CLI mode but breaks in some test runners. The dashboard injects its own path (`src/dashboard/app.py:13-15`).
3. **Don't recreate deleted files.** The severity engine was removed (`src/severity/` does not exist) — don't re-add it without an explicit request. The stale `models/staff_classifier.joblib` was deleted because `StaffClassifier` is rule-based and doesn't save anything to disk.

## Known Limitations

- **Aspect detection on short texts** uses the keyword booster with synthetic 0.90 confidence. Real LR-based accuracy on inputs <6 tokens is unreliable by design.
- **Aspect detection can't output conflicting sentiments for the same aspect.** A feedback like "The nurses were good but the nurses were bad" triggers `nursing_care` once with a single sentiment (the LR's prediction, not per-clause).
- **The dashboard's multi-line `st.markdown(f"""...""")` calls can render raw HTML tags as a code block** when an interpolation variable is empty (e.g., empty `pills_html`). The fix is per-line `lstrip()` on the f-string before passing to `st.markdown`. This is documented in the `roadmap` file.
- **Model accuracy is bounded by 715 unique training texts.** Don't expect generalization improvements from algorithm changes — more labeled data is the lever.

## Conventions to Follow

1. **When adding a new keyword list, prefer extending `ASPECT_KEYWORDS`** in `src/aspect_detection/keyword_gate.py` rather than creating a new module. The pipeline already uses this everywhere.
2. **When adding a new short-text rule, prefer extending the inline booster** in `src/pipeline.py:107` rather than creating a new method. The pattern is established.
3. **When adding test cases, add to `test_new_feedbacks.py`** (smoke tests) or `run_live_feedbacks.py` (15-case live evaluation). Don't create new test files.
4. **When the dashboard fails to render HTML, check for 4+ spaces of indentation** in multi-line f-strings before `st.markdown(..., unsafe_allow_html=True)`.
5. **When measuring latency, test the cold path.** Warm-cache benchmarks hide cold-start issues (MiniLM model load, UMAP transforms, etc.).

## Debugging Tips

- **Embedding shape errors**: the cache returns 1-D vectors for single-text and 2-D for batch. If you see a 3-D array, it's a `np.asarray` quirk — check `src/embeddings/embedding_cache.py:11-34`.
- **Dashboard import errors**: Streamlit reruns the entire script on every interaction. If a model is slow to load, it'll feel like a hang — verify the spinner is showing.
- **DB schema mismatch**: if you change `src/database/connection.py`, you must delete `data/processed/patient_feedback.db` and re-run `scripts/populate_db.py`. The schema is `CREATE TABLE IF NOT EXISTS` — old tables persist.
- **Mixed-sentiment feedback**: split on `but/however/and/.` is regex-based and order-sensitive. For unparseable inputs the whole text becomes a single clause and gets one sentiment.

## What's Deliberately Out of Scope

- **LLM-based aspect extraction.** This is a non-LLM project by design.
- **Batched inference API.** `analyze(text)` is single-input. Use `scripts/batch_inference.py` for batch jobs.
- **External vector store.** Embeddings live in an in-process LRU. No FAISS, no Pinecone, no pgvector.
- **Production monitoring.** No Prometheus, no Grafana, no model drift detection.
- **Multi-language support.** Dataset is English-only; keyword gate is English-only.