import os
import sys
import json
import yaml
import pandas as pd
import numpy as np

sys.path.append(os.path.dirname(__file__))

from src.preprocessing.normalizer import TextNormalizer
from src.embeddings.embedding_cache import EmbeddingCache
from src.embeddings.embedder import Embedder
from src.aspect_detection.classifier import AspectDetector
from src.aspect_detection.keyword_gate import aspect_matches_clause
from src.clause_extraction.clause_extractor import ClauseExtractor
from src.sentiment.analyzer import SentimentAnalyzer
from src.service_line.classifier import ServiceLineClassifier
from src.staff_classifier.classifier import StaffClassifier
from src.clustering.theme_discoverer import ThemeDiscoverer
from src.pipeline import InferencePipeline, demo_inference


def load_config():
    with open("configs/config.yaml", "r") as f:
        return yaml.safe_load(f)


def prepare_training_data(df: pd.DataFrame):
    normalizer = TextNormalizer()
    texts = [normalizer.normalize(t) for t in df["Feedback Text"].tolist()]

    service_lines = df["Service Line"].tolist()

    aspect_labels = []
    for val in df["Aspects Detected"]:
        if pd.isna(val):
            aspect_labels.append([])
        else:
            aspect_labels.append([a.strip() for a in str(val).split(",") if a.strip()])

    # Sentiment training data: train on CLAUSES that carry each aspect's
    # polarity, not on the full text. This fixes two problems:
    #   1. The previous full-text dedup dropped all but the last aspect's
    #      sentiment per row, leaking only one polarity for multi-aspect
    #      feedbacks (e.g. "doctor good + nurse bad" lost one of them).
    #   2. The model was trained on full-text embeddings but inference
    #      ran on clause embeddings — a distribution mismatch.
    clause_extractor = ClauseExtractor()
    sent_texts, sent_labels = [], []
    for text, aspect_sents in zip(texts, df["Aspect Sentiments"]):
        if pd.isna(aspect_sents):
            continue
        clauses = clause_extractor.extract(text)
        for pair in str(aspect_sents).split(";"):
            pair = pair.strip()
            if ":" not in pair:
                continue
            aspect_name, sent_label = pair.split(":", 1)
            aspect_name = aspect_name.strip()
            sent_label = sent_label.strip()
            # Find the clause that best matches this aspect. If no clause
            # matches (e.g. the aspect term is implicit in the full text),
            # skip this pair rather than leak the full text.
            matched_clause = None
            for clause in clauses:
                if aspect_matches_clause(aspect_name, clause):
                    matched_clause = clause
                    break
            if matched_clause is None:
                continue
            sent_texts.append(matched_clause)
            sent_labels.append(sent_label)

    emerging_texts = []
    for text, theme in zip(texts, df["Emerging Theme"]):
        if not pd.isna(theme):
            emerging_texts.append(text)

    return {
        "texts": texts,
        "service_lines": service_lines,
        "aspect_labels": aspect_labels,
        "sent_texts": sent_texts,
        "sent_labels": sent_labels,
        "emerging_texts": emerging_texts,
    }


def train_all_models(config):
    print("=" * 60)
    print("  Training All Models")
    print("=" * 60)

    models_dir = config["paths"]["models_dir"]
    os.makedirs(models_dir, exist_ok=True)

    dataset_path = os.path.join(config["paths"]["data_dir"],
                                "Hospital_Patient_Feedback_Dataset_5000 - "
                                "Hospital_Patient_Feedback_Dataset_5000.csv.csv")
    df = pd.read_csv(dataset_path)

    cache = EmbeddingCache(Embedder(config["models"]["embedding_model"]))
    data = prepare_training_data(df)

    # 1. Service Line Classifier
    print("\n--- Service Line Classifier ---")
    sl_clf = ServiceLineClassifier(
        cache,
        confidence_threshold=config["classifiers"]["confidence_threshold"],
    )
    sl_clf.train(data["texts"], data["service_lines"])
    sl_clf.save(os.path.join(models_dir, "service_line.joblib"))

    # 2. Aspect Detector
    print("\n--- Aspect Detector ---")
    aspect_clf = AspectDetector(
        cache,
        confidence_threshold=config["classifiers"]["aspect_threshold"],
    )
    aspect_clf.train(data["texts"], data["aspect_labels"])
    aspect_clf.save(os.path.join(models_dir, "aspect_detector.joblib"))

    # 3. Sentiment Analyzer
    print("\n--- Sentiment Analyzer ---")
    sent_clf = SentimentAnalyzer(
        cache,
        confidence_threshold=config["classifiers"]["sentiment_threshold"],
    )
    sent_clf.train(data["sent_texts"], data["sent_labels"])
    sent_clf.save(os.path.join(models_dir, "sentiment_model.joblib"))

    # 4. Staff Classifier (rule-based, no training needed)
    print("\n--- Staff Classifier (rule-based) ---")
    staff_clf = StaffClassifier()

    # 5. Theme Discoverer
    print("\n--- Theme Discoverer ---")
    theme_discoverer = ThemeDiscoverer(cache)
    if data["emerging_texts"]:
        theme_discoverer.train(data["emerging_texts"])
        theme_discoverer.save(os.path.join(models_dir, "theme_discoverer.joblib"))

    print("\n" + "=" * 60)
    print("  All models trained and saved")
    print("=" * 60)

    return cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_discoverer


# InferencePipeline and demo_inference moved to src/pipeline.py


if __name__ == "__main__":
    config = load_config()
    cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_disc = train_all_models(config)
    pipeline = InferencePipeline(config, cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_disc)
    demo_inference(pipeline)
