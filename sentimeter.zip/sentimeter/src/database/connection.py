"""
SQLite persistence layer.

Tables (aspect-based schema):
- feedbacks: one row per feedback with service_line + routing.
- aspects: one row per (feedback, aspect) with sentiment, department, staff.
- clauses: one row per (feedback, clause) with attached aspect/sentiment.
- emerging_themes: cluster summaries from the theme discoverer.

The schema intentionally has no overall_sentiment / overall_severity /
requires_escalation: the unit of analysis is the per-aspect (sentiment,
department) tuple.
"""
import sqlite3
import os
from typing import Dict, List, Any

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                       "data", "processed", "patient_feedback.db")


def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=60)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS feedbacks (
            id TEXT PRIMARY KEY,
            raw_text TEXT NOT NULL,
            service_line TEXT,
            service_confidence REAL,
            departments_involved TEXT,
            source TEXT,
            known_category_match INTEGER DEFAULT 1,
            emerging_theme TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS aspects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            feedback_id TEXT NOT NULL,
            aspect TEXT NOT NULL,
            sentiment TEXT,
            confidence REAL,
            evidence TEXT,
            staff_category TEXT,
            department TEXT,
            FOREIGN KEY (feedback_id) REFERENCES feedbacks(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS clauses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            feedback_id TEXT NOT NULL,
            clause_text TEXT NOT NULL,
            aspect TEXT,
            sentiment TEXT,
            FOREIGN KEY (feedback_id) REFERENCES feedbacks(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS emerging_themes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            theme_name TEXT NOT NULL,
            example_text TEXT,
            feedback_ids TEXT,
            suggested_category TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("CREATE INDEX IF NOT EXISTS idx_aspects_feedback ON aspects(feedback_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_clauses_feedback ON clauses(feedback_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_aspects_department ON aspects(department)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_aspects_sentiment ON aspects(sentiment)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_aspects_aspect ON aspects(aspect)")

    conn.commit()
    conn.close()


class BatchInserter:
    def __init__(self, conn: sqlite3.Connection, batch_size: int = 100):
        self.conn = conn
        self.batch_size = batch_size
        self.feedbacks_buffer: List[tuple] = []
        self.aspects_buffer: List[tuple] = []
        self.clauses_buffer: List[tuple] = []
        self._inserted = 0

    def add(self, data: Dict[str, Any]):
        fid = data.get("feedback_id")
        self.feedbacks_buffer.append((
            fid,
            data.get("raw_text", ""),
            data.get("service_line", ""),
            data.get("service_confidence", 0.0),
            ",".join(data.get("routing", [])),
            data.get("source", ""),
            1 if data.get("known_category_match", True) else 0,
            data.get("emerging_theme", ""),
        ))
        for a in data.get("aspects", []):
            self.aspects_buffer.append((
                fid,
                a.get("aspect", ""),
                a.get("sentiment", ""),
                a.get("confidence", 0.0),
                a.get("evidence", ""),
                a.get("staff_category", ""),
                a.get("department", ""),
            ))
        for c in data.get("clauses", []):
            self.clauses_buffer.append((
                fid,
                c.get("text", ""),
                c.get("aspect", ""),
                c.get("sentiment", ""),
            ))
        self._inserted += 1
        if self._inserted % self.batch_size == 0:
            self.flush()

    def flush(self):
        cursor = self.conn.cursor()
        cursor.executemany("""
            INSERT OR REPLACE INTO feedbacks
            (id, raw_text, service_line, service_confidence,
             departments_involved, source, known_category_match,
             emerging_theme)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, self.feedbacks_buffer)
        if self.aspects_buffer:
            cursor.executemany("""
                INSERT INTO aspects
                (feedback_id, aspect, sentiment, confidence, evidence,
                 staff_category, department)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, self.aspects_buffer)
        if self.clauses_buffer:
            cursor.executemany("""
                INSERT INTO clauses
                (feedback_id, clause_text, aspect, sentiment)
                VALUES (?, ?, ?, ?)
            """, self.clauses_buffer)
        self.conn.commit()
        self.feedbacks_buffer.clear()
        self.aspects_buffer.clear()
        self.clauses_buffer.clear()

    def close(self):
        if self.feedbacks_buffer or self.aspects_buffer or self.clauses_buffer:
            self.flush()
