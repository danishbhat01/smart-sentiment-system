"""
Router mapping aspects and staff categories to hospital departments.

Department names match the ground-truth Routing Departments column.
"""

ASPECT_DEPARTMENT_MAP = {
    "wait_time": "Patient Flow Operations",
    "staff_politeness": "Patient Relations",
    "doctor_explanation": "Medical Services / Clinical Operations",
    "nursing_care": "Nursing Administration",
    "cleanliness": "Housekeeping / EVS",
    "billing_transparency": "Patient Financial Services",
    "report_turnaround": "Diagnostics / Lab Operations",
    "communication": "Patient Relations",
    "discharge_process": "Care Coordination",
    "food_quality": "Dietary Services",
    "pain_management": "Pain Management Team",
    "safety_concern": "Risk Management & Safety",
    "parking": "General Administration",
    "language_barrier": "General Administration",
    "wheelchair_access": "General Administration",
    "cafeteria_pricing": "General Administration",
    "visiting_hours": "General Administration",
    "wifi": "General Administration",
    "app_crash": "General Administration",
}


# Maps a staff-category token (from staff classifier) to a GT department.
# GT uses labels like "Doctor", "Reception", "Clinical Staff" — not snake_case.
STAFF_TOKEN_TO_DEPARTMENT = {
    "doctor": "Medical Services / Clinical Operations",
    "reception_staff": "Patient Relations",
    "reception": "Patient Relations",
    "nursing_staff": "Nursing Administration",
    "clinical staff": "Nursing Administration",
    "billing_staff": "Patient Financial Services",
    "billing staff": "Patient Financial Services",
    "lab_staff": "Diagnostics / Lab Operations",
    "lab staff": "Diagnostics / Lab Operations",
    "pharmacy_staff": "General Administration",
    "pharmacist": "General Administration",
    "housekeeping": "Housekeeping / EVS",
    "dietary staff": "Dietary Services",
    "emergency staff": "Risk Management & Safety",
    "support staff": "General Administration",
    "coordinator": "Care Coordination",
    "attendant_security": "Risk Management & Safety",
}


class Router:
    def route_aspect(self, aspect: str, staff_category: str = "") -> str:
        if staff_category and staff_category in STAFF_TOKEN_TO_DEPARTMENT:
            return STAFF_TOKEN_TO_DEPARTMENT[staff_category]
        return ASPECT_DEPARTMENT_MAP.get(aspect, "General Administration")

    def route(self, aspects: list) -> list:
        departments = []
        for item in aspects:
            dept = self.route_aspect(
                item.get("aspect", ""),
                item.get("staff_category", ""),
            )
            if dept not in departments:
                departments.append(dept)
        return departments