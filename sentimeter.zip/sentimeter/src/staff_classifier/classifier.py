"""
Rule-based staff mention classifier.

Maps trigger phrases in feedback text to ground-truth staff labels:
    Doctor, Reception, Clinical Staff, Billing Staff, Lab Staff,
    Pharmacist, Housekeeping, Dietary Staff, Emergency Staff,
    Support Staff, Coordinator, Nursing Staff.

Multi-label support: returns ALL matching categories (the ground-truth
column can hold comma-separated labels like "Doctor, Reception").
"""
from typing import Dict, List


STAFF_KEYWORDS = {
    "Doctor": ["doctor", "consultant", "surgeon", "physician", "dr.", "specialist"],
    "Reception": ["reception", "front desk", "registration", "receptionist",
                  "front office", "reception desk", "appointment counter"],
    "Clinical Staff": ["clinical staff", "nurse", "nursing", "sister", "staff nurse"],
    "Nursing Staff": ["nurse", "nursing", "sister", "staff nurse"],
    "Billing Staff": ["billing", "cashier", "insurance desk", "billing counter",
                     "finance"],
    "Lab Staff": ["lab", "lab technician", "lab staff", "radiology",
                 "pathology", "technician"],
    "Pharmacist": ["pharmacy", "pharmacist", "medicine counter", "pharma",
                  "medical store"],
    "Housekeeping": ["housekeeping", "cleaning", "cleaner", "housekeeper",
                    "cleaning staff", "sweeper"],
    "Dietary Staff": ["dietary", "cafeteria", "food service", "meal staff"],
    "Emergency Staff": ["emergency staff", "casualty staff"],
    "Support Staff": ["attendant", "security", "ward boy", "wardboy",
                     "gate staff", "support staff"],
    "Coordinator": ["coordinator", "floor coordinator", "patient coordinator",
                    "co ordinator", "co-ordinator"],
}


# Canonical ordering for staff categories (priority when multiple match)
STAFF_CATEGORIES = list(STAFF_KEYWORDS.keys())


class StaffClassifier:
    def __init__(self):
        pass

    def predict(self, text: str) -> Dict:
        """Return ALL matching staff categories in priority order."""
        lower = text.lower()
        matched = []
        for cat, keywords in STAFF_KEYWORDS.items():
            count = sum(1 for kw in keywords if kw in lower)
            if count > 0:
                matched.append((cat, count))

        # Sort by count desc then by canonical order
        order = {c: i for i, c in enumerate(STAFF_CATEGORIES)}
        matched.sort(key=lambda x: (-x[1], order.get(x[0], 999)))

        categories = [m[0] for m in matched]
        confidence = 0.85 if categories else 0.50

        return {
            "staff_categories": categories,
            "staff_category": categories[0] if categories else "",
            "staff_confidence": confidence,
            "fallback": not categories,
        }

    def train(self, texts=None, labels=None, test_size=None):
        pass

    def save(self, path: str):
        pass

    def load(self, path: str):
        pass