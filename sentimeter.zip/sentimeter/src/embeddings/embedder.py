import numpy as np
from sentence_transformers import SentenceTransformer


class Embedder:
    _model = None

    @classmethod
    def get_model(cls, model_name: str = "all-MiniLM-L6-v2"):
        if cls._model is None:
            cls._model = SentenceTransformer(model_name)
        return cls._model

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.model_name = model_name
        self._model = self.get_model(model_name)

    def encode(self, texts, show_progress_bar: bool = False):
        if isinstance(texts, str):
            texts = [texts]
        embeddings = self._model.encode(texts, show_progress_bar=show_progress_bar)
        return np.array(embeddings)
