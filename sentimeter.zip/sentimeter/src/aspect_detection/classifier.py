import numpy as np
import joblib
from typing import List, Dict
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, hamming_loss

from src.embeddings.embedding_cache import EmbeddingCache

KNOWN_ASPECTS = [
    "wait_time", "staff_politeness", "doctor_explanation", "nursing_care",
    "cleanliness", "billing_transparency", "report_turnaround", "communication",
    "discharge_process", "food_quality", "pain_management", "safety_concern",
    "parking", "language_barrier", "wheelchair_access", "cafeteria_pricing",
    "visiting_hours", "wifi", "app_crash",
]


class AspectDetector:
    def __init__(
        self,
        embedding_cache: EmbeddingCache,
        confidence_threshold: float = 0.50,
    ):
        self.cache = embedding_cache
        self.confidence_threshold = confidence_threshold
        self.model = OneVsRestClassifier(
            LogisticRegression(
                max_iter=1000, C=1.0,
                class_weight="balanced", random_state=42, n_jobs=-1,
            )
        )
        self.binarizer = MultiLabelBinarizer(classes=KNOWN_ASPECTS)
        self.is_trained = False

    def train(self, texts: List[str], labels: List[List[str]], test_size: float = 0.2):
        # Deduplicate by text to avoid leakage (same text in train and test)
        seen = {}
        for t, l in zip(texts, labels):
            if t not in seen:
                seen[t] = l
        unique_texts = list(seen.keys())
        unique_labels = list(seen.values())
        print(f"[AspectDetector] Unique texts: {len(unique_texts)} (from {len(texts)} rows)")

        X = self.cache.encode_and_store(unique_texts)
        y = self.binarizer.fit_transform(unique_labels)

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42,
        )

        self.model.fit(X_train, y_train)
        self.is_trained = True

        y_pred = self.model.predict(X_test)
        h_loss = hamming_loss(y_test, y_pred)
        print(f"\n[AspectDetector] Hamming Loss (LR, unique-text split): {h_loss:.4f}")
        print("[AspectDetector] Classification Report:")
        print(classification_report(
            y_test, y_pred,
            target_names=self.binarizer.classes_,
            zero_division=0,
        ))

    def predict(self, text: str) -> List[Dict]:
        if not self.is_trained:
            return []

        embedding = self.cache.encode(text).flatten()
        return self.predict_with_embedding(embedding)[0]

    def predict_with_embedding(self, embeddings: np.ndarray) -> List[List[Dict]]:
        """Predict aspects from a pre-computed embedding matrix.

        `embeddings` must be a 2-D array of shape (n_texts, 384).
        Returns a list of length n_texts, each entry the list of aspect
        dicts sorted by descending confidence.
        """
        if not self.is_trained:
            return [[] for _ in range(embeddings.shape[0])]

        proba_matrix = self.model.predict_proba(embeddings)
        classes = self.binarizer.classes_
        threshold = self.confidence_threshold

        results = []
        for i in range(embeddings.shape[0]):
            row_results = []
            for j, cls in enumerate(classes):
                conf = float(proba_matrix[i, j])
                if conf >= threshold:
                    row_results.append({"aspect": cls, "confidence": round(conf, 3)})
            row_results.sort(key=lambda x: x["confidence"], reverse=True)
            results.append(row_results)
        return results

    def predict_multi(self, text: str) -> List[Dict]:
        return self.predict(text)

    def save(self, path: str):
        joblib.dump({"model": self.model, "binarizer": self.binarizer}, path)

    def load(self, path: str):
        data = joblib.load(path)
        self.model = data["model"]
        self.binarizer = data["binarizer"]
        self.is_trained = True