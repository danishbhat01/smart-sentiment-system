import numpy as np
import joblib
from typing import Dict, List
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

from src.embeddings.embedding_cache import EmbeddingCache

POSITIVE_KEYWORDS = [
    "good", "great", "excellent", "amazing", "wonderful", "helpful", "kind",
    "caring", "polite", "professional", "attentive", "friendly", "prompt",
    "quick", "fast", "satisfied", "happy", "pleased", "clean", "comfortable",
    "recommend", "appreciate", "thank", "best", "love", "nice", "clear",
    "explained", "thorough", "supportive", "responsive", "gentle", "patient",
    "well", "easy", "smooth",
]

NEGATIVE_KEYWORDS = [
    "rude", "bad", "terrible", "horrible", "awful", "delayed", "slow",
    "late", "unacceptable", "frustrated", "angry", "ignored", "problem",
    "issue", "complaint", "dirty", "unclean", "pain", "hurt", "worst",
    "hate", "poor", "disappointed", "careless", "arrogant", "shouted",
    "rushed", "negligence", "wrong", "harm", "emergency", "waited", "wait",
    "long", "no one", "nobody", "didn't", "couldn't", "wouldn't", "not",
]


class SentimentAnalyzer:
    def __init__(self, embedding_cache: EmbeddingCache, confidence_threshold: float = 0.60):
        self.cache = embedding_cache
        self.confidence_threshold = confidence_threshold
        self.model = LogisticRegression(
            max_iter=1000, C=1.0,
            class_weight="balanced", random_state=42, n_jobs=-1,
        )
        self.encoder = LabelEncoder()
        self.is_trained = False

    def _keyword_score(self, text: str) -> Dict[str, float]:
        lower = text.lower()
        pos_count = sum(1 for kw in POSITIVE_KEYWORDS if kw in lower)
        neg_count = sum(1 for kw in NEGATIVE_KEYWORDS if kw in lower)
        return {"positive": pos_count, "negative": neg_count}

    def train(self, texts: List[str], sentiments: List[str], test_size: float = 0.2):
        # Deduplicate by text to avoid leakage
        seen = {}
        for t, l in zip(texts, sentiments):
            if t not in seen:
                seen[t] = l
        unique_texts = list(seen.keys())
        unique_labels = list(seen.values())
        print(f"[SentimentAnalyzer] Unique texts: {len(unique_texts)} (from {len(texts)} samples)")

        X = self.cache.encode_and_store(unique_texts)
        y = self.encoder.fit_transform(unique_labels)

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y,
        )

        self.model.fit(X_train, y_train)
        self.is_trained = True

        y_pred = self.model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        print(f"\n[SentimentAnalyzer] Accuracy (LR, unique-text split): {acc:.4f}")
        print(classification_report(
            y_test, y_pred,
            target_names=self.encoder.classes_,
            zero_division=0,
        ))

    def predict(self, text: str) -> Dict:
        if not self.is_trained:
            kw = self._keyword_score(text)
            return {"sentiment": "positive" if kw["positive"] > kw["negative"] else "negative", "confidence": 0.5}

        embedding = self.cache.encode(text).flatten()
        return self.predict_with_embedding(embedding, text)

    def predict_with_embedding(self, embedding: np.ndarray, text: str) -> Dict:
        """Predict sentiment from a pre-computed embedding.

        The caller must supply the original `text` so the keyword-override
        path remains operational (same behavior as predict()).
        """
        if not self.is_trained:
            kw = self._keyword_score(text)
            return {"sentiment": "positive" if kw["positive"] > kw["negative"] else "negative", "confidence": 0.5}

        probas = self.model.predict_proba(embedding.reshape(1, -1))[0]
        classes = self.encoder.classes_

        # ML prediction
        ml_idx = int(np.argmax(probas))
        ml_sentiment = classes[ml_idx]
        ml_conf = float(probas[ml_idx])

        # Keyword adjustment
        kw = self._keyword_score(text)
        pos_kw, neg_kw = kw["positive"], kw["negative"]
        kw_diff = pos_kw - neg_kw

        # If keywords strongly disagree with ML, override
        if kw_diff >= 2 and ml_sentiment != "positive":
            return {"sentiment": "positive", "confidence": 0.70, "method": "kw_override"}
        if kw_diff <= -2 and ml_sentiment != "negative":
            return {"sentiment": "negative", "confidence": 0.70, "method": "kw_override"}

        if ml_conf >= self.confidence_threshold or ml_conf >= 0.40:
            return {"sentiment": ml_sentiment, "confidence": round(ml_conf, 3), "method": "ml"}

        return {"sentiment": "neutral", "confidence": round(ml_conf, 3), "method": "default_neutral"}

    def save(self, path: str):
        joblib.dump({"model": self.model, "encoder": self.encoder}, path)

    def load(self, path: str):
        data = joblib.load(path)
        self.model = data["model"]
        self.encoder = data["encoder"]
        self.is_trained = True