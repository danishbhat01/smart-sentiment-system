import numpy as np
from typing import List, Dict
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.cluster import DBSCAN
from src.embeddings.embedding_cache import EmbeddingCache

class OnlineClusterer:
    """
    Actively clusters 'anomaly' feedbacks (those that failed to match 
    any known aspects or pre-trained themes) to discover brand new 
    themes on the fly during batch inference.
    """
    def __init__(self, eps: float = 0.15, min_samples: int = 2):
        # eps=0.15 in cosine distance means a minimum similarity of 0.85
        self.eps = eps
        self.min_samples = min_samples

    def discover_new_themes(self, texts: List[str], cache: EmbeddingCache) -> Dict[str, str]:
        """
        Runs DBSCAN on anomaly texts directly in 384-D cosine space.
        Returns a dict mapping original text to a newly discovered theme string.
        Unclustered points map to "".
        """
        if not texts or len(texts) < self.min_samples:
            return {t: "" for t in texts}

        embeddings = cache.encode_and_store(texts)
        
        cluster_model = DBSCAN(eps=self.eps, min_samples=self.min_samples, metric="cosine")
        labels = cluster_model.fit_predict(embeddings)

        theme_labels = {}
        
        try:
            vectorizer = CountVectorizer(stop_words="english", max_features=500)
            word_matrix = vectorizer.fit_transform(texts)
            vocab = vectorizer.get_feature_names_out()
        except ValueError:
            # Fails if all texts contain only stop words
            vocab = None

        text_to_theme = {t: "" for t in texts}

        if vocab is not None:
            for cluster_id in sorted(set(labels)):
                if cluster_id < 0:
                    continue
                mask = labels == cluster_id
                cluster_word_counts = word_matrix[mask].sum(axis=0).A1
                top_indices = cluster_word_counts.argsort()[-5:][::-1]
                top_words = [vocab[i] for i in top_indices if cluster_word_counts[i] > 0]
                label = " / ".join(top_words[:4]) if top_words else f"new_theme_{cluster_id}"
                
                # Prefix with [NEW]
                theme_labels[cluster_id] = f"[NEW] {label}"

        for i, text in enumerate(texts):
            c_id = labels[i]
            if c_id >= 0 and c_id in theme_labels:
                text_to_theme[text] = theme_labels[c_id]

        return text_to_theme
