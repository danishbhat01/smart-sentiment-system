"""
Theme discoverer using UMAP + DBSCAN for cluster discovery, with cosine
similarity on 384-D centroids for inference-time point assignment.

Why this design:
- UMAP transform() on a single point is slow (~12-20s on CPU). We use UMAP
  only at training time for cluster discovery; inference uses fast cosine
  similarity on the original 384-D embeddings.
- Cosine similarity on MiniLM-L6 (384-D, unit-normalized-friendly) is the
  correct metric for semantic similarity. Euclidean distance in 5-D UMAP
  space was mathematically wrong.
- DBSCAN stays as the actual clustering algorithm; only the inference-time
  point-assignment is replaced.
"""
import numpy as np
import joblib
from typing import List, Dict
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.cluster import DBSCAN
import umap

from src.embeddings.embedding_cache import EmbeddingCache


class ThemeDiscoverer:
    def __init__(
        self,
        embedding_cache: EmbeddingCache,
        n_neighbors: int = 15,
        n_components: int = 5,
        eps: float = 0.5,
        min_samples: int = 2,
    ):
        self.cache = embedding_cache
        self.n_neighbors = n_neighbors
        self.n_components = n_components
        self.eps = eps
        self.min_samples = min_samples
        self.reducer = None
        self.vectorizer = None
        self.is_trained = False
        self.theme_labels = {}
        self._training_labels = None
        self._training_reduced = None
        # Cluster centroids in original 384-D space — used for inference.
        self.cluster_centroids: Dict[int, np.ndarray] = {}
        # Minimum similarity threshold to consider a match.
        self.min_similarity = 0.5

    def train(self, texts: List[str]):
        if len(texts) < 5:
            self.is_trained = False
            return

        embeddings = self.cache.encode_and_store(texts)

        # UMAP for cluster discovery only.
        self.reducer = umap.UMAP(
            n_neighbors=min(self.n_neighbors, len(texts) - 1),
            n_components=self.n_components,
            random_state=42,
            metric="cosine",
        )
        reduced = self.reducer.fit_transform(embeddings)

        # DBSCAN clusters on the UMAP-reduced space.
        cluster_model = DBSCAN(eps=self.eps, min_samples=self.min_samples, metric="euclidean")
        labels = cluster_model.fit_predict(reduced)

        self._training_reduced = reduced
        self._training_labels = labels

        # Compute cluster centroids in the original 384-D embedding space.
        self.cluster_centroids = {}
        for cluster_id in sorted(set(labels)):
            if cluster_id < 0:
                continue
            mask = labels == cluster_id
            cluster_embeddings = embeddings[mask]
            centroid = cluster_embeddings.mean(axis=0)
            # L2-normalize for cosine similarity via dot product.
            norm = np.linalg.norm(centroid)
            if norm > 0:
                centroid = centroid / norm
            self.cluster_centroids[int(cluster_id)] = centroid

        # Label clusters with top keywords (kept from old design).
        self.vectorizer = CountVectorizer(stop_words="english", max_features=500)
        word_matrix = self.vectorizer.fit_transform(texts)
        vocab = self.vectorizer.get_feature_names_out()

        n_clusters = len(set(l for l in labels if l >= 0))
        noise_count = sum(1 for l in labels if l < 0)
        print(f"[ThemeDiscoverer] UMAP+DBSCAN: {n_clusters} clusters, {noise_count} noise points")
        print(f"[ThemeDiscoverer] Centroid cache: {len(self.cluster_centroids)} cluster centroids stored")

        for cluster_id in sorted(set(labels)):
            if cluster_id < 0:
                continue
            mask = labels == cluster_id
            cluster_word_counts = word_matrix[mask].sum(axis=0).A1
            top_indices = cluster_word_counts.argsort()[-5:][::-1]
            top_words = [vocab[i] for i in top_indices if cluster_word_counts[i] > 0]
            label = " / ".join(top_words[:4]) if top_words else f"cluster_{cluster_id}"
            self.theme_labels[cluster_id] = label

        self.is_trained = True

    def discover(self, texts: List[str]) -> List[Dict]:
        if not self.is_trained or not texts:
            return [{"text": t, "theme": None, "topic_id": -1, "confidence": 0.0} for t in texts]

        embeddings = self.cache.encode_and_store(texts)

        results = []
        for i, text in enumerate(texts):
            point = embeddings[i]
            norm = np.linalg.norm(point)
            if norm > 0:
                point_norm = point / norm
            else:
                point_norm = point

            best_cluster_id = -1
            best_similarity = -1.0

            for cluster_id, centroid in self.cluster_centroids.items():
                # Cosine similarity = dot product of L2-normalized vectors.
                sim = float(np.dot(point_norm, centroid))
                if sim > best_similarity:
                    best_similarity = sim
                    best_cluster_id = int(cluster_id)

            # Confidence = normalized cosine similarity in [0, 1].
            confidence = round((best_similarity + 1.0) / 2.0, 3) if best_similarity >= self.min_similarity else 0.0

            # If below threshold, treat as no match.
            if best_similarity < self.min_similarity:
                theme_label = None
                cluster_id_out = -1
                confidence_out = round(best_similarity, 3)
            else:
                theme_label = self.theme_labels.get(best_cluster_id)
                cluster_id_out = best_cluster_id
                confidence_out = confidence

            results.append({
                "text": text,
                "theme": theme_label,
                "topic_id": cluster_id_out,
                "confidence": confidence_out,
            })

        return results

    def get_cluster_summary(self) -> List[Dict]:
        if self._training_labels is None:
            return []
        summaries = []
        for cluster_id, label in sorted(self.theme_labels.items()):
            count = int((self._training_labels == cluster_id).sum())
            summaries.append({"cluster_id": cluster_id, "theme": label, "count": count})
        return summaries

    def save(self, path: str):
        data = {
            "reducer": self.reducer,
            "vectorizer": self.vectorizer,
            "theme_labels": self.theme_labels,
            "training_labels": self._training_labels,
            "training_reduced": self._training_reduced,
            "cluster_centroids": self.cluster_centroids,
            "min_similarity": self.min_similarity,
        }
        joblib.dump(data, path)

    def load(self, path: str):
        data = joblib.load(path)
        self.reducer = data.get("reducer")
        self.vectorizer = data.get("vectorizer")
        self.theme_labels = data.get("theme_labels", {})
        self._training_labels = data.get("training_labels")
        self._training_reduced = data.get("training_reduced")
        self.cluster_centroids = data.get("cluster_centroids", {})
        self.min_similarity = data.get("min_similarity", 0.5)
        self.is_trained = True