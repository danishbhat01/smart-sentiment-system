import re

class TextNormalizer:
    def normalize(self, text: str) -> str:
        if not text or not isinstance(text, str):
            return ""
        text = text.strip()
        text = re.sub(r"\s+", " ", text)
        return text
