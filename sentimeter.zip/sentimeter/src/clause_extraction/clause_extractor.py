import re
from typing import List


class ClauseExtractor:
    SPLIT_PATTERN = re.compile(
        r"\s+(but|however|although|though|whereas|while|yet|nevertheless|on the other hand|"
        r"on the contrary|except that|despite this|nonetheless)\s+",
        re.IGNORECASE,
    )

    def extract(self, text: str) -> List[str]:
        if not text or not isinstance(text, str):
            return []
        clauses = self.SPLIT_PATTERN.split(text)
        result = []
        for i, clause in enumerate(clauses):
            clause = clause.strip().strip(",.!?;:")
            if clause and len(clause) > 5:
                if i > 0 and clause.lower() in {
                    "but", "however", "although", "though", "whereas",
                    "while", "yet", "nevertheless",
                }:
                    continue
                result.append(clause)
        return result if result else [text.strip()]
