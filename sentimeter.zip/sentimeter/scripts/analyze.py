"""
Analyze a single piece of patient feedback and output structured JSON.

Usage:
    python scripts/analyze.py "The doctor was good but the nurse was rude"
    python scripts/analyze.py --file feedback.txt
    python scripts/analyze.py --interactive
"""
import argparse
import json
import sys
import uuid

from scripts._inference_utils import load_pipeline, ensure_models_trained


def analyze_text(pipeline, text: str, source: str = "Manual Input") -> dict:
    fid = f"FB-CLI-{uuid.uuid4().hex[:8]}"
    result = pipeline.analyze(text, source=source, feedback_id=fid)
    return result


def print_pretty(result: dict):
    print("\n" + "=" * 60)
    print(f"  FEEDBACK ANALYSIS — {result['feedback_id']}")
    print("=" * 60)
    print(f"Source:         {result['source']}")
    print(f"Service Line:   {result['service_line']} (confidence: {result['service_confidence']})")
    if result.get("emerging_theme"):
        print(f"Emerging Theme: {result['emerging_theme']}")

    if result["aspects"]:
        print(f"\nDetected Aspects ({len(result['aspects'])}):")
        for i, asp in enumerate(result["aspects"], 1):
            print(f"\n  {i}. {asp['aspect']} — {asp['sentiment'].upper()} "
                  f"(conf: {asp['confidence']})")
            print(f"     Evidence: {asp['evidence']}")
            print(f"     Department: {asp['department']}")
            if asp.get("staff_category"):
                print(f"     Staff: {asp['staff_category']}")
    else:
        print("\n  No aspects detected.")

    if result.get("routing"):
        print(f"\nRouting Queue: {', '.join(result['routing'])}")

    if result.get("clauses"):
        print(f"\nClauses Detected ({len(result['clauses'])}):")
        for i, clause in enumerate(result["clauses"], 1):
            text_preview = clause["text"][:80] + "..." if len(clause["text"]) > 80 else clause["text"]
            print(f"  {i}. [{clause['aspect'] or '—'}:{clause['sentiment']}] {text_preview}")


def main():
    parser = argparse.ArgumentParser(description="Analyze patient feedback → JSON")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("text", nargs="?", help="Feedback text to analyze")
    group.add_argument("--file", "-f", help="Read feedback text from a file")
    group.add_argument("--interactive", "-i", action="store_true",
                       help="Interactive REPL mode")
    parser.add_argument("--source", "-s", default="Manual Input",
                        help="Source label (e.g., 'Email', 'Google Review')")
    parser.add_argument("--json", action="store_true",
                        help="Output raw JSON only (no pretty print)")
    parser.add_argument("--output", "-o", help="Save JSON to file")

    args = parser.parse_args()

    ensure_models_trained()
    pipeline = load_pipeline()

    if args.interactive:
        print("Patient Feedback Analyzer — Interactive Mode")
        print("Type feedback text and press Enter. Type 'exit' or 'quit' to stop.\n")
        while True:
            try:
                text = input("feedback> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye.")
                break
            if not text:
                continue
            if text.lower() in ("exit", "quit"):
                break
            result = analyze_text(pipeline, text, source="Interactive")
            print_pretty(result)
            print()
        return

    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            text = f.read().strip()
    else:
        text = args.text

    result = analyze_text(pipeline, text, source=args.source)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)
        print(f"Saved JSON output to: {args.output}", file=sys.stderr)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print_pretty(result)


if __name__ == "__main__":
    main()
