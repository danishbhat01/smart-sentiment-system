import os
import sys
import time
import pandas as pd
from tqdm import tqdm

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.database.connection import init_db, get_db_connection, BatchInserter
from src.preprocessing.normalizer import TextNormalizer
from src.embeddings.embedding_cache import EmbeddingCache
from src.embeddings.embedder import Embedder
from src.aspect_detection.classifier import AspectDetector
from src.sentiment.analyzer import SentimentAnalyzer
from src.service_line.classifier import ServiceLineClassifier
from src.staff_classifier.classifier import StaffClassifier
from src.clustering.theme_discoverer import ThemeDiscoverer
from src.pipeline import InferencePipeline
from src.clause_extraction.clause_extractor import ClauseExtractor


def load_config():
    import yaml as _yaml
    with open("configs/config.yaml", "r") as f:
        return _yaml.safe_load(f)


def load_models(config):
    models_dir = config["paths"]["models_dir"]
    print("[PopulateDB] Creating embedder cache...", flush=True)
    cache = EmbeddingCache(Embedder(config["models"]["embedding_model"]))

    print("[PopulateDB] Loading service_line.joblib...", flush=True)
    sl_clf = ServiceLineClassifier(cache)
    sl_clf.load(os.path.join(models_dir, "service_line.joblib"))

    print("[PopulateDB] Loading aspect_detector.joblib...", flush=True)
    aspect_clf = AspectDetector(cache)
    aspect_clf.load(os.path.join(models_dir, "aspect_detector.joblib"))

    print("[PopulateDB] Loading sentiment_model.joblib...", flush=True)
    sent_clf = SentimentAnalyzer(cache)
    sent_clf.load(os.path.join(models_dir, "sentiment_model.joblib"))

    print("[PopulateDB] Initializing rule-based staff classifier...", flush=True)
    staff_clf = StaffClassifier()

    print("[PopulateDB] Loading theme_discoverer.joblib...", flush=True)
    theme_disc = ThemeDiscoverer(cache)
    theme_path = os.path.join(models_dir, "theme_discoverer.joblib")
    if os.path.exists(theme_path):
        theme_disc.load(theme_path)

    print("[PopulateDB] All models loaded.", flush=True)
    return cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_disc


def main():
    t_start = time.time()

    print("=" * 60, flush=True)
    print("  Populating SQLite Database", flush=True)
    print("=" * 60, flush=True)

    config = load_config()
    init_db()

    print(f"[PopulateDB] Loading models (t={time.time()-t_start:.1f}s)...", flush=True)
    cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_disc = load_models(config)
    pipeline = InferencePipeline(
        config, cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_disc,
    )
    pipeline.enable_timing_report(every_n_calls=100)

    dataset_path = os.path.join(
        config["paths"]["data_dir"],
        "Hospital_Patient_Feedback_Dataset_5000 - "
        "Hospital_Patient_Feedback_Dataset_5000.csv.csv",
    )
    print(f"[PopulateDB] Loading dataset: {dataset_path}", flush=True)
    df = pd.read_csv(dataset_path)
    total = len(df)
    print(f"[PopulateDB] Loaded {total} rows (t={time.time()-t_start:.1f}s)", flush=True)

    # --- Step 1: Collect all unique texts + clauses ---
    print(f"[PopulateDB] Step 1: Collecting unique texts and clauses (t={time.time()-t_start:.1f}s)...", flush=True)
    normalizer = TextNormalizer()
    clause_extractor = ClauseExtractor()
    all_texts = set()
    all_clauses = set()

    for text in tqdm(df["Feedback Text"], desc="Scanning rows", unit="row"):
        t = normalizer.normalize(str(text))
        all_texts.add(t)
        for clause in clause_extractor.extract(t):
            all_clauses.add(clause)

    all_texts = list(all_texts)
    all_clauses = list(all_clauses)
    print(f"[PopulateDB] Unique texts: {len(all_texts)}, unique clauses: {len(all_clauses)}", flush=True)

    # --- Step 2: Batch encode everything ---
    print(f"[PopulateDB] Step 2: Batch encoding (t={time.time()-t_start:.1f}s)...", flush=True)
    t_enc_start = time.time()
    cache.encode_and_store(all_texts)
    cache.encode_and_store(all_clauses)
    print(f"[PopulateDB] Encoded all in {time.time()-t_enc_start:.1f}s (cache={len(cache._cache)})", flush=True)

    # --- Step 3: Process each row ---
    print(f"[PopulateDB] Step 3: Per-row inference + DB insert (t={time.time()-t_start:.1f}s)...", flush=True)
    sources = [
        "Email", "Phone Call", "Feedback Form", "Google Review",
        "Social Media", "WhatsApp", "Post-discharge Survey", "App Feedback",
    ]

    conn = get_db_connection()
    batch = BatchInserter(conn, batch_size=100)

    for idx, row in tqdm(df.iterrows(), total=total, desc="Populating DB", unit="row"):
        text = str(row["Feedback Text"])
        source = sources[idx % len(sources)]
        fid = str(row["Feedback Id"])

        result = pipeline.analyze(text, source=source, feedback_id=fid)

        if pd.notna(row.get("Emerging Theme")):
            result["known_category_match"] = False
            result["emerging_theme"] = row["Emerging Theme"]

        batch.add(result)

    batch.close()
    conn.close()

    # Populate emerging themes from the trained model
    print(f"[PopulateDB] Step 4: Inserting emerging themes (t={time.time()-t_start:.1f}s)...", flush=True)
    if theme_disc.is_trained:
        summary = theme_disc.get_cluster_summary()
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM emerging_themes")
        for s in summary:
            cur.execute(
                "INSERT INTO emerging_themes (theme_name, example_text, suggested_category) VALUES (?, ?, ?)",
                (s["theme"], f"Cluster of {s['count']} feedbacks", "Emerging category"),
            )
        conn.commit()
        conn.close()
        print(f"[PopulateDB] Inserted {len(summary)} emerging themes", flush=True)

    print(f"[PopulateDB] Done! Processed {total} rows in {time.time()-t_start:.1f}s total", flush=True)


if __name__ == "__main__":
    main()