"""
Comprehensive evaluation of trained models on the held-out test set.

Generates a detailed report covering:
- Service Line classifier (accuracy, per-class f1, confusion summary)
- Aspect Detector (hamming loss, per-aspect f1, samples f1)
- Sentiment Analyzer (accuracy, precision/recall)
- Staff classifier (rule-based, no test needed)
- Theme Discoverer (cluster quality stats)

Usage:
    python scripts/evaluate.py
    python scripts/evaluate.py --output eval_report.json
"""
import argparse
import json
import os
import sys
from typing import Dict

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, classification_report, hamming_loss,
    f1_score, precision_score, recall_score,
)
from sklearn.model_selection import train_test_split

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.embeddings.embedding_cache import EmbeddingCache
from src.embeddings.embedder import Embedder
from src.aspect_detection.classifier import AspectDetector
from src.sentiment.analyzer import SentimentAnalyzer
from src.service_line.classifier import ServiceLineClassifier
from scripts._inference_utils import ensure_models_trained


def load_dataset(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Dataset not found: {path}")
    return pd.read_csv(path)


def prepare_data(df: pd.DataFrame, normalizer):
    texts = [normalizer.normalize(t) for t in df["Feedback Text"].tolist()]
    service_lines = df["Service Line"].tolist()

    aspect_labels = []
    for val in df["Aspects Detected"]:
        if pd.isna(val):
            aspect_labels.append([])
        else:
            aspect_labels.append([a.strip() for a in str(val).split(",") if a.strip()])

    sent_texts, sent_labels = [], []
    for text, aspect_sents in zip(texts, df["Aspect Sentiments"]):
        if pd.isna(aspect_sents):
            continue
        for pair in str(aspect_sents).split(";"):
            if ":" in pair:
                _, sent_part = pair.split(":", 1)
                sent_texts.append(text)
                sent_labels.append(sent_part.strip())

    # Deduplicate to avoid leakage (same text in train + test)
    seen = {}
    for t, sl, al in zip(texts, service_lines, aspect_labels):
        if t not in seen:
            seen[t] = (sl, al)
    unique_texts = list(seen.keys())
    unique_sl = [v[0] for v in seen.values()]
    unique_al = [v[1] for v in seen.values()]

    seen_sent = {}
    for t, s in zip(sent_texts, sent_labels):
        if t not in seen_sent:
            seen_sent[t] = s
    unique_sent_texts = list(seen_sent.keys())
    unique_sent_labels = list(seen_sent.values())

    print(f"[Evaluate] Unique texts: {len(unique_texts)} (from {len(texts)} rows)")
    print(f"[Evaluate] Unique sentiment samples: {len(unique_sent_texts)} (from {len(sent_texts)} samples)")

    return {
        "texts": unique_texts,
        "service_lines": unique_sl,
        "aspect_labels": unique_al,
        "sent_texts": unique_sent_texts,
        "sent_labels": unique_sent_labels,
    }


def evaluate_service_line(clf, X, y_true, unique_texts):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_true, test_size=0.2, random_state=42, stratify=y_true,
    )
    print(f"[ServiceLineClassifier] Train: {len(X_train)} unique texts, Test: {len(X_test)} unique texts")
    y_pred_encoded = clf.model.predict(X_test)
    y_pred = clf.encoder.inverse_transform(y_pred_encoded)
    y_test = list(y_test)
    y_pred = list(y_pred)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(
        y_test, y_pred,
        target_names=clf.encoder.classes_,
        output_dict=True, zero_division=0,
    )
    print(f"\n[ServiceLineClassifier] Test Accuracy: {acc:.4f}")
    print(classification_report(
        y_test, y_pred,
        target_names=clf.encoder.classes_,
        zero_division=0,
    ))
    return {
        "accuracy": float(acc),
        "macro_f1": float(report["macro avg"]["f1-score"]),
        "weighted_f1": float(report["weighted avg"]["f1-score"]),
        "per_class": {
            k: {"precision": v["precision"], "recall": v["recall"], "f1": v["f1-score"]}
            for k, v in report.items() if k not in ("accuracy", "macro avg", "weighted avg")
        },
    }


def evaluate_aspect(clf, X, y_labels):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_labels, test_size=0.2, random_state=42,
    )
    print(f"[AspectDetector] Train: {len(X_train)} unique texts, Test: {len(X_test)} unique texts")
    y_train_bin = clf.binarizer.transform(y_train)
    y_test_bin = clf.binarizer.transform(y_test)

    # Re-fit on training portion to ensure clean evaluation
    from sklearn.multiclass import OneVsRestClassifier
    from sklearn.linear_model import LogisticRegression
    eval_clf = OneVsRestClassifier(
        LogisticRegression(max_iter=1000, C=1.0, class_weight="balanced", random_state=42)
    )
    eval_clf.fit(X_train, y_train_bin)
    y_pred = eval_clf.predict(X_test)

    h_loss = float(hamming_loss(y_test_bin, y_pred))
    samples_f1 = float(f1_score(y_test_bin, y_pred, average="samples", zero_division=0))
    micro_f1 = float(f1_score(y_test_bin, y_pred, average="micro", zero_division=0))
    macro_f1 = float(f1_score(y_test_bin, y_pred, average="macro", zero_division=0))

    print(f"\n[AspectDetector] Hamming Loss: {h_loss:.4f}")
    print(f"[AspectDetector] Samples F1: {samples_f1:.4f}")
    print(f"[AspectDetector] Micro F1: {micro_f1:.4f}")
    print(f"[AspectDetector] Macro F1: {macro_f1:.4f}")
    print(classification_report(
        y_test_bin, y_pred,
        target_names=clf.binarizer.classes_,
        zero_division=0,
    ))

    return {
        "hamming_loss": h_loss,
        "samples_f1": samples_f1,
        "micro_f1": micro_f1,
        "macro_f1": macro_f1,
    }


def evaluate_sentiment(clf, X, y_true):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_true, test_size=0.2, random_state=42, stratify=y_true,
    )
    print(f"[SentimentAnalyzer] Train: {len(X_train)} unique texts, Test: {len(X_test)} unique texts")
    y_pred_encoded = clf.model.predict(X_test)
    y_pred = clf.encoder.inverse_transform(y_pred_encoded)
    y_test = list(y_test)
    y_pred = list(y_pred)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(
        y_test, y_pred,
        target_names=clf.encoder.classes_,
        output_dict=True, zero_division=0,
    )
    print(f"\n[SentimentAnalyzer] Test Accuracy: {acc:.4f}")
    print(classification_report(
        y_test, y_pred,
        target_names=clf.encoder.classes_,
        zero_division=0,
    ))
    return {
        "accuracy": float(acc),
        "macro_f1": float(report["macro avg"]["f1-score"]),
        "weighted_f1": float(report["weighted avg"]["f1-score"]),
        "per_class": {
            k: {"precision": v["precision"], "recall": v["recall"], "f1": v["f1-score"]}
            for k, v in report.items() if k not in ("accuracy", "macro avg", "weighted avg")
        },
    }


def main():
    parser = argparse.ArgumentParser(description="Evaluate all trained models")
    parser.add_argument("--dataset", default=None,
                        help="Path to evaluation CSV (default: data/Hospital...)")
    parser.add_argument("--output", "-o", help="Save JSON report to file")
    parser.add_argument("--config", default="configs/config.yaml",
                        help="Path to config.yaml")
    args = parser.parse_args()

    ensure_models_trained()

    import yaml
    with open(args.config, "r") as f:
        config = yaml.safe_load(f)

    # Default dataset path
    if not args.dataset:
        data_dir = config["paths"]["data_dir"]
        candidates = [f for f in os.listdir(data_dir) if f.endswith(".csv")]
        if not candidates:
            raise FileNotFoundError(f"No CSV found in {data_dir}")
        args.dataset = os.path.join(data_dir, candidates[0])

    print(f"[Evaluate] Dataset: {args.dataset}")
    df = load_dataset(args.dataset)
    print(f"[Evaluate] Loaded {len(df)} rows")

    # Load models + pre-encode all texts once
    models_dir = config["paths"]["models_dir"]
    cache = EmbeddingCache(Embedder(config["models"]["embedding_model"]))

    print("[Evaluate] Loading models...")
    sl_clf = ServiceLineClassifier(cache)
    sl_clf.load(os.path.join(models_dir, "service_line.joblib"))

    aspect_clf = AspectDetector(cache)
    aspect_clf.load(os.path.join(models_dir, "aspect_detector.joblib"))

    sent_clf = SentimentAnalyzer(cache)
    sent_clf.load(os.path.join(models_dir, "sentiment_model.joblib"))

    # Pre-compute embeddings
    from src.preprocessing.normalizer import TextNormalizer
    normalizer = TextNormalizer()
    data = prepare_data(df, normalizer)

    print("[Evaluate] Encoding all texts...")
    X = cache.encode_and_store(data["texts"])
    X_sent = cache.encode_and_store(data["sent_texts"])

    print("\n" + "=" * 60)
    print("  EVALUATION RESULTS")
    print("=" * 60)

    report = {
        "dataset": args.dataset,
        "total_rows": len(df),
        "unique_texts": len(data["texts"]),
        "service_line": evaluate_service_line(sl_clf, X, data["service_lines"], data["texts"]),
        "aspect_detector": evaluate_aspect(aspect_clf, X, data["aspect_labels"]),
        "sentiment_analyzer": evaluate_sentiment(sent_clf, X_sent, data["sent_labels"]),
        "staff_classifier": {
            "type": "rule-based",
            "note": "No model evaluation needed — deterministic keyword matching",
        },
    }

    # Summary
    print("\n" + "=" * 60)
    print("  SUMMARY")
    print("=" * 60)
    print(f"  Service Line Accuracy:     {report['service_line']['accuracy']:.4f}")
    print(f"  Service Line Macro F1:     {report['service_line']['macro_f1']:.4f}")
    print(f"  Aspect Detector Hamming:   {report['aspect_detector']['hamming_loss']:.4f}")
    print(f"  Aspect Detector Samples F1:{report['aspect_detector']['samples_f1']:.4f}")
    print(f"  Sentiment Accuracy:        {report['sentiment_analyzer']['accuracy']:.4f}")
    print(f"  Sentiment Macro F1:        {report['sentiment_analyzer']['macro_f1']:.4f}")
    print(f"  Staff Classifier:          rule-based (no metrics)")

    if args.output:
        with open(args.output, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\n[Evaluate] Saved JSON report to: {args.output}")

    return report


if __name__ == "__main__":
    main()