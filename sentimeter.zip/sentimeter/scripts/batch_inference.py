"""
Batch inference on a CSV file.

Reads a CSV with at minimum a 'text' or 'feedback' column.
For each row, runs the inference pipeline and outputs structured JSON per row.

Usage:
    python scripts/batch_inference.py --input new_feedback.csv --output predictions.json
    python scripts/batch_inference.py --input data.csv --output predictions.csv --format csv
"""
import argparse
import json
import sys
import uuid
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from scripts._inference_utils import load_pipeline, ensure_models_trained


TEXT_COLUMN_CANDIDATES = ["text", "feedback", "feedback_text", "comment", "Feedback Text", "message"]


def detect_text_column(df: pd.DataFrame) -> str:
    for col in TEXT_COLUMN_CANDIDATES:
        if col in df.columns:
            return col
    raise ValueError(
        f"No text column found. Tried: {TEXT_COLUMN_CANDIDATES}. "
        f"Available columns: {list(df.columns)}"
    )


def run_batch(input_path: str, output_path: str, output_format: str = "json",
              id_column: str = None, source_column: str = None, source: str = "Batch") -> dict:
    ensure_models_trained()
    pipeline = load_pipeline()

    print(f"[BatchInference] Loading CSV: {input_path}")
    df = pd.read_csv(input_path)
    print(f"[BatchInference] Loaded {len(df)} rows")

    text_col = detect_text_column(df)
    print(f"[BatchInference] Using text column: '{text_col}'")

    if id_column and id_column in df.columns:
        ids = df[id_column].astype(str).tolist()
    else:
        ids = [f"FB-BATCH-{uuid.uuid4().hex[:8]}" for _ in range(len(df))]

    if source_column and source_column in df.columns:
        sources = df[source_column].astype(str).tolist()
    else:
        sources = [source] * len(df)

    results = []
    for i, (text, fid, src) in enumerate(tqdm(
        list(zip(df[text_col].astype(str), ids, sources)),
        desc="Inferring", unit="row",
    )):
        result = pipeline.analyze(text, source=src, feedback_id=fid)
        results.append(result)

    # Write output
    output_path = Path(output_path)
    if output_format == "json":
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        print(f"[BatchInference] Saved {len(results)} JSON records to: {output_path}")
    elif output_format == "csv":
        flat_rows = []
        for r in results:
            base = {
                "feedback_id": r["feedback_id"],
                "source": r["source"],
                "raw_text": r["raw_text"],
                "service_line": r["service_line"],
                "service_confidence": r["service_confidence"],
                "emerging_theme": r.get("emerging_theme", ""),
                "routing": "|".join(r.get("routing", [])),
                "num_aspects": len(r.get("aspects", [])),
            }
            for asp in r.get("aspects", []):
                row = dict(base)
                row.update({
                    "aspect": asp["aspect"],
                    "aspect_sentiment": asp["sentiment"],
                    "aspect_confidence": asp["confidence"],
                    "evidence": asp["evidence"],
                    "staff_category": asp.get("staff_category", ""),
                    "department": asp["department"],
                })
                flat_rows.append(row)
            if not r.get("aspects"):
                flat_rows.append(base)
        pd.DataFrame(flat_rows).to_csv(output_path, index=False)
        print(f"[BatchInference] Saved {len(flat_rows)} CSV rows to: {output_path}")

    # Print summary
    sl_counts = pd.Series([r["service_line"] for r in results]).value_counts()
    pos_aspects = sum(1 for r in results for a in r.get("aspects", []) if a.get("sentiment") == "positive")
    neg_aspects = sum(1 for r in results for a in r.get("aspects", []) if a.get("sentiment") == "negative")

    print("\n=== BATCH INFERENCE SUMMARY ===")
    print(f"Total feedbacks processed: {len(results)}")
    print(f"Service lines: {dict(sl_counts)}")
    print(f"Positive aspects: {pos_aspects}")
    print(f"Negative aspects: {neg_aspects}")

    return {"results": results, "count": len(results)}


def main():
    parser = argparse.ArgumentParser(description="Batch inference on a CSV file")
    parser.add_argument("--input", "-i", required=True, help="Input CSV path")
    parser.add_argument("--output", "-o", required=True, help="Output file path")
    parser.add_argument("--format", "-f", choices=["json", "csv"], default="json",
                        help="Output format (default: json)")
    parser.add_argument("--id-column", help="Column name to use as feedback ID (auto-generated if absent)")
    parser.add_argument("--source-column", help="Column name to use as source")
    parser.add_argument("--source", default="Batch",
                        help="Default source label if no source column provided")

    args = parser.parse_args()
    run_batch(
        input_path=args.input,
        output_path=args.output,
        output_format=args.format,
        id_column=args.id_column,
        source_column=args.source_column,
        source=args.source,
    )


if __name__ == "__main__":
    main()
