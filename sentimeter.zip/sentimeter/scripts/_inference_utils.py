import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.embeddings.embedding_cache import EmbeddingCache
from src.embeddings.embedder import Embedder
from src.aspect_detection.classifier import AspectDetector
from src.sentiment.analyzer import SentimentAnalyzer
from src.service_line.classifier import ServiceLineClassifier
from src.staff_classifier.classifier import StaffClassifier
from src.clustering.theme_discoverer import ThemeDiscoverer
from src.pipeline import InferencePipeline


def load_pipeline(config_path: str = "configs/config.yaml"):
    import yaml
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    models_dir = config["paths"]["models_dir"]
    cache = EmbeddingCache(Embedder(config["models"]["embedding_model"]))

    sl_clf = ServiceLineClassifier(cache)
    sl_clf.load(os.path.join(models_dir, "service_line.joblib"))

    aspect_clf = AspectDetector(cache)
    aspect_clf.load(os.path.join(models_dir, "aspect_detector.joblib"))

    sent_clf = SentimentAnalyzer(cache)
    sent_clf.load(os.path.join(models_dir, "sentiment_model.joblib"))

    staff_clf = StaffClassifier()

    theme_disc = ThemeDiscoverer(cache)
    theme_path = os.path.join(models_dir, "theme_discoverer.joblib")
    if os.path.exists(theme_path):
        theme_disc.load(theme_path)

    return InferencePipeline(config, cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_disc)


def ensure_models_trained():
    models_dir = "models"
    required = [
        "service_line.joblib",
        "aspect_detector.joblib",
        "sentiment_model.joblib",
        "theme_discoverer.joblib",
    ]
    missing = [m for m in required if not os.path.exists(os.path.join(models_dir, m))]
    if missing:
        raise FileNotFoundError(
            f"Missing trained models: {missing}\n"
            f"Please run: python main.py"
        )