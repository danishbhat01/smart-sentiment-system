import re
from typing import List


class ClauseExtractor:
    SPLIT_PATTERN = re.compile(
        r"(?i)(\b(?:but|and|or|however|although|though|whereas|while|yet|nevertheless)\b|,|;)",
    )

    def extract(self, text: str, spacy_doc=None) -> List[str]:
        if not text or not isinstance(text, str):
            return []
            
        sentences = [sent.text.strip() for sent in spacy_doc.sents] if spacy_doc else [text.strip()]
        
        nlp = None
        if spacy_doc:
            from src.sentiment.analyzer import get_nlp
            nlp = get_nlp()
            
        final_clauses = []
        
        for sent in sentences:
            raw_splits = self.SPLIT_PATTERN.split(sent)
            
            merged_clauses = []
            current_clause = ""
            
            for chunk in raw_splits:
                if not chunk or not chunk.strip():
                    continue
                    
                # If it's a delimiter, just append it
                if self.SPLIT_PATTERN.match(chunk.strip()):
                    current_clause += chunk
                    continue
                    
                # Otherwise append the text
                current_clause += chunk
                
                if nlp:
                    chunk_doc = nlp(current_clause)
                    has_subj = any(t.dep_ in ('nsubj', 'nsubjpass', 'csubj', 'expl') for t in chunk_doc)
                    has_verb = any(t.pos_ in ('VERB', 'AUX') for t in chunk_doc)
                    
                    if has_subj and has_verb:
                        # Found a full independent clause
                        cleaned = current_clause.strip(" ,;")
                        if len(cleaned.split()) > 2:
                            merged_clauses.append(cleaned)
                            current_clause = ""
                else:
                    # Fallback if no spaCy: just split
                    cleaned = current_clause.strip(" ,;")
                    if len(cleaned.split()) > 2:
                        merged_clauses.append(cleaned)
                        current_clause = ""
                        
            # Handle leftovers
            if current_clause.strip():
                cleaned = current_clause.strip(" ,;")
                if merged_clauses:
                    merged_clauses[-1] += " " + cleaned
                elif cleaned:
                    merged_clauses.append(cleaned)
                    
            final_clauses.extend(merged_clauses)
            
        # Clean up empty strings and return
        result = [c.strip() for c in final_clauses if c.strip()]
        return result if result else [text.strip()]
