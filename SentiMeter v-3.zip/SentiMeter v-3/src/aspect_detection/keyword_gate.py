"""
Aspect keyword gate - suppress ML aspect predictions on clauses that lack
discriminative trigger words for that aspect.

Each aspect has a curated list of phrases/keywords that almost always
appear when that aspect is genuinely expressed in feedback. When the
multi-label aspect classifier fires on a clause that contains NONE of
these triggers, the prediction is treated as a spurious generalization.

If the gate rejects a (clause, aspect) match, the aspect is rerouted to
a synthesized "general" clause made from the full normalized text so the
routing/department pipeline still sees the aspect.

Why this exists: the LR aspect classifier was trained on the *whole*
feedback text, but the inference pipeline assigns aspects to individual
clauses. With a 0.50 threshold the model over-predicts aspects on clauses
that semantically don't carry them (e.g. "Doctor explained everything well"
gets pain_management at 0.52).
"""

from typing import List, Tuple


ASPECT_KEYWORDS: dict = {
    "wait_time": [
        "wait", "waited", "waiting", "queue", "delay", "delayed",
        "slow", "long wait", "took too", "hours", "promptly",
        "quickly", "minutes", "backed up",
    ],
    "staff_politeness": [
        "rude", "dismissive", "unhelpful", "ignored", "polite",
        "professional", "behaved", "courteous", "attitude", "behaviour",
        "behavior", "manners", "respectful", "interaction",
        "staff", "inconvenience",
    ],
    "doctor_explanation": [
        "explained", "explain", "explanation", "findings",
        "procedure explained", "treatment plan", "doctor explained",
        "consultant", "physician", "doctor", "questions were answered",
    ],
    "nursing_care": [
        "nurse", "nurses", "nursing", "sister", "staff nurse",
        "clinical staff", "responded", "respond", "caring",
        "attentive", "seemed rushed",
    ],
    "cleanliness": [
        "cleaning", "clean", "dirty", "unclean", "washroom",
        "restroom", "housekeeping", "stain", "maintained", "tidy",
        "messy", "filthy",
    ],
    "billing_transparency": [
        "bill", "billing", "charge", "charges", "fees",
        "unexpected charges", "estimate", "insurance", "payment",
        "cost", "expensive", "refund", "cashier", "overcharged",
    ],
    "report_turnaround": [
        "report", "results", "lab result", "mri", "x-ray",
        "scan", "test result", "report delayed", "report arrived",
        "turnaround",
    ],
    "communication": [
        "communication", "informed", "update", "updates",
        "regular updates", "kept me informed", "no one informed",
        "nobody informed", "clear communication", "throughout",
    ],
    "discharge_process": [
        "discharge", "discharged", "instructions unclear",
        "discharge process", "paperwork", "discharge took",
        "several hours", "delayed discharge",
    ],
    "food_quality": [
        "food", "meal", "meals", "cafeteria food", "food quality",
        "arrived cold", "fresh", "dietary", "tasty", "tasteless",
    ],
    "pain_management": [
        "pain", "pain relief", "pain was", "pain not",
        "managed adequately", "not managed", "relief took",
        "pain management", "painful",
    ],
    "safety_concern": [
        "safety", "safety check", "safety protocol", "protocols",
        "skipped", "concern", "patient safety", "risk",
        "negligence", "harm", "accident", "dangerous",
        "critical", "emergency", "urgent",
    ],
    "parking": [
        "parking", "park", "parking lot", "parking space",
        "parking problem", "parking issue",
    ],
    "language_barrier": [
        "language", "language barrier", "english", "translator",
        "interpret", "language issue", "language problem",
        "hindi", "regional language",
    ],
    "wheelchair_access": [
        "wheelchair", "wheel chair", "accessibility",
        "ramp", "mobility", "disabled access",
    ],
    "cafeteria_pricing": [
        "cafeteria", "cafeteria pricing", "cafeteria price",
        "food price", "canteen",
    ],
    "visiting_hours": [
        "visiting hours", "visitors", "visitor", "visiting time",
        "visiting policy",
    ],
    "wifi": [
        "wifi", "wi-fi", "internet", "network", "wi fi",
        "connectivity",
    ],
    "app_crash": [
        "app", "application", "crash", "crashed", "app kept crashing",
        "could not download", "couldn't download", "login",
        "portal", "website",
    ],
}


def _build_pattern(keywords: List[str]):
    """Compile a single regex matching any keyword as a whole word/phrase."""
    import re
    escaped = []
    for kw in keywords:
        escaped.append(re.escape(kw.lower()))
    return re.compile(r"\b(?:" + "|".join(escaped) + r")\b", re.IGNORECASE)


_PATTERNS = {aspect: _build_pattern(kws) for aspect, kws in ASPECT_KEYWORDS.items()}


def aspect_matches_clause(aspect: str, clause: str) -> bool:
    """True if `clause` text contains at least one trigger keyword for `aspect`."""
    pattern = _PATTERNS.get(aspect)
    if pattern is None:
        return True
    return bool(pattern.search(clause))


def filter_aspects_for_clauses(
    aspects_per_clause: List[List[dict]],
    clauses: List[str],
    full_text: str,
) -> Tuple[List[List[dict]], List[dict]]:
    """Apply keyword gate to per-clause aspect predictions.

    `aspects_per_clause[i]` is the list of aspect dicts returned by the
    classifier for `clauses[i]`. The gate removes any aspect whose
    discriminative keywords are absent from that clause. If the gate
    drops *all* aspects for a clause but the full-text model produced
    predictions for that clause originally, the highest-confidence
    dropped aspect is attached to a synthesized general clause built
    from the full text so routing/department still sees it.

    Returns (filtered_aspects_per_clause, fallback_aspects).
    """
    filtered: List[List[dict]] = []
    fallbacks: List[dict] = []
    for aspects, clause in zip(aspects_per_clause, clauses):
        kept = [a for a in aspects if aspect_matches_clause(a["aspect"], clause)]
        dropped = [a for a in aspects if a not in kept]
        if dropped and not kept:
            best = max(dropped, key=lambda a: a["confidence"])
            fallbacks.append({
                "aspect": best["aspect"],
                "confidence": best["confidence"],
                "evidence": full_text,
            })
        filtered.append(kept)
    return filtered, fallbacks