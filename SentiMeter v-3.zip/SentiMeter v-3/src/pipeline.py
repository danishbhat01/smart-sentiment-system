"""
Inference pipeline: orchestrates all classifiers and produces a structured,
aspect-based analysis of a single piece of patient feedback.

The output is a list of (aspect, sentiment, evidence_clause, department)
tuples. Each detected aspect is grounded in the clause that best expresses
it (via keyword matching), and each aspect carries its own sentiment.

Pipeline stages:
  1. Normalize the raw text.
  2. Service-line classification on the full text (LR).
  3. Clause extraction (regex split on contrast conjunctions).
  4. Aspect detection on the FULL-TEXT embedding (matches training distribution).
  5. For each detected aspect, find the best matching clause as evidence.
  6. Per-clause sentiment classification (LR + keyword override).
  7. Staff mention classification (rule-based, called for clinical aspects).
  8. Per-aspect routing (aspect/staff -> department).
  9. Emerging-theme discovery for feedbacks that yield no aspects.
"""
import time

import numpy as np

from src.preprocessing.normalizer import TextNormalizer
from src.clause_extraction.clause_extractor import ClauseExtractor
from src.routing.router import Router
from src.aspect_detection.keyword_gate import aspect_matches_clause
from src.sentiment.analyzer import get_nlp


CLINICAL_ASPECTS_FOR_STAFF = {
    "staff_politeness", "doctor_explanation", "nursing_care",
    "billing_transparency", "report_turnaround", "discharge_process",
    "pain_management", "safety_concern",
}


class InferencePipeline:
    def __init__(self, config, cache, sl_clf, aspect_clf, sent_clf, staff_clf, theme_discoverer):
        self.config = config
        self.cache = cache
        self.normalizer = TextNormalizer()
        self.clause_extractor = ClauseExtractor()
        self.sl_clf = sl_clf
        self.aspect_clf = aspect_clf
        self.sent_clf = sent_clf
        self.staff_clf = staff_clf
        self.theme_discoverer = theme_discoverer
        self.router = Router()
        self._timing_totals = {"sl": 0.0, "clause": 0.0, "aspect": 0.0, "sent": 0.0,
                               "route": 0.0, "db": 0.0, "total": 0.0, "calls": 0}
        self._print_every = None

    def enable_timing_report(self, every_n_calls: int):
        self._print_every = every_n_calls

    def _predict_sentiment_for_clauses(self, clauses: list, embeddings: np.ndarray) -> list:
        """Per-clause sentiment using pre-computed embeddings.

        Returns a list of sentiment strings, one per clause, aligned with
        `clauses` and `embeddings`.
        """
        if not clauses:
            return []
        if not self.sent_clf.is_trained:
            return ["neutral"] * len(clauses)

        results = []
        for i, clause in enumerate(clauses):
            r = self.sent_clf.predict_with_embedding(embeddings[i], clause)
            results.append(r.get("sentiment", "neutral"))
        return results

    def analyze(self, text: str, source: str = "", feedback_id: str = "") -> dict:
        _t0 = time.perf_counter()

        raw_text = text
        text = self.normalizer.normalize(text)

        nlp = get_nlp()
        spacy_doc = nlp(text) if nlp else None

        # Encode the full text once. Service-line uses this directly.
        full_embedding = self.cache.encode(text).flatten()

        # Clause extraction (regex split on contrast conjunctions and sentences).
        clauses = self.clause_extractor.extract(text, spacy_doc=spacy_doc)
        _t_clause = time.perf_counter() - _t0

        # Batch encode all clauses in one MiniLM forward pass.
        clause_embeddings = self.cache.encode_and_store(clauses)

        # === ASPECT DETECTION ===
        # Predict on the FULL-TEXT embedding (matches training distribution).
        # Aspect model was trained on full feedback texts, not clauses.
        if self.aspect_clf.is_trained:
            aspect_probs = self.aspect_clf.model.predict_proba(
                full_embedding.reshape(1, -1)
            )[0]
            classes = self.aspect_clf.binarizer.classes_
            threshold = self.aspect_clf.confidence_threshold
            detected_aspects = [
                {"aspect": cls, "confidence": float(p)}
                for cls, p in zip(classes, aspect_probs)
                if p >= threshold
            ]
            detected_aspects.sort(key=lambda x: x["confidence"], reverse=True)
        else:
            detected_aspects = []

        # --- HYBRID EVIDENCE BOOSTER ---
        # Runs on all text lengths by evaluating individual clauses.
        from src.sentiment.analyzer import POSITIVE_KEYWORDS, NEGATIVE_KEYWORDS
        from src.aspect_detection.keyword_gate import ASPECT_KEYWORDS
        
        detected_names = {a["aspect"] for a in detected_aspects}
        for clause in clauses:
            clause_lower = clause.lower()
            has_sent = any(kw in clause_lower for kw in POSITIVE_KEYWORDS + NEGATIVE_KEYWORDS)
            
            if has_sent:
                for cls in ASPECT_KEYWORDS:
                    if cls not in detected_names and aspect_matches_clause(cls, clause):
                        detected_aspects.append({
                            "aspect": cls,
                            "confidence": 0.65
                        })
                        detected_names.add(cls) # Prevent adding multiple times
                        
        detected_aspects.sort(key=lambda x: x["confidence"], reverse=True)

        _t_aspect = time.perf_counter() - _t0

        # Service-line (uses pre-computed full embedding).
        sl_result = self.sl_clf.predict_with_embedding(full_embedding, text)
        service_line = sl_result["service_line"]
        service_confidence = sl_result["service_confidence"]
        _t_sl = time.perf_counter() - _t0

        # === ASPECT-TO-CLAUSE EVIDENCE MAPPING ===
        # For each detected aspect, find the clause whose text best carries
        # that aspect's trigger keyword. Use that clause's embedding for
        # the per-aspect sentiment prediction. If no clause matches, fall
        # back to the full text (embedding and evidence).
        clause_index = {c: i for i, c in enumerate(clauses)}

        # Pre-compute sentiment for each unique matched clause so we don't
        # re-encode the same clause multiple times for adjacent aspects.
        clause_sentiment_cache: dict = {}

        def _sentiment_for(evidence: str, fallback_emb: np.ndarray, aspect: str, doc=None):
            if evidence in clauses:
                idx = clause_index[evidence]
                cache_key = (evidence, aspect)
                if cache_key not in clause_sentiment_cache:
                    r = self.sent_clf.predict_with_embedding(clause_embeddings[idx], evidence, aspect=aspect, spacy_doc=doc)
                    clause_sentiment_cache[cache_key] = r.get("sentiment", "neutral")
                return clause_sentiment_cache[cache_key], clause_embeddings[idx]
            # Full-text fallback.
            r = self.sent_clf.predict_with_embedding(full_embedding, evidence, aspect=aspect, spacy_doc=doc)
            return r.get("sentiment", "neutral"), full_embedding

        aspect_results = []
        clause_results = []

        for asp in detected_aspects:
            aspect_name = asp["aspect"]
            aspect_conf = asp["confidence"]

            from src.aspect_detection.keyword_gate import ASPECT_KEYWORDS
            
            best_clause = None
            best_score = 0
            
            candidate_kws = ASPECT_KEYWORDS.get(aspect_name, [])
            for clause in clauses:
                if aspect_matches_clause(aspect_name, clause):
                    # calculate a simple overlap score
                    score = sum(1 for kw in candidate_kws if kw in clause.lower())
                    if score > best_score:
                        best_score = score
                        best_clause = clause
            
            # Suppress false positives: If no clause matches, check the full text.
            # If the full text also lacks keywords, discard the aspect entirely
            # unless it's an overwhelmingly confident ML prediction (>= 0.85).
            if best_clause is None and not aspect_matches_clause(aspect_name, text):
                if aspect_conf < 0.85:
                    continue
                    
            evidence = best_clause if best_clause is not None else text

            sentiment, _ = _sentiment_for(evidence, full_embedding, aspect_name, doc=spacy_doc)

            staff_category = ""
            if aspect_name in CLINICAL_ASPECTS_FOR_STAFF:
                staff_result = self.staff_clf.predict(evidence)
                staff_category = staff_result.get("staff_category", "")

            department = self.router.route_aspect(aspect_name, staff_category)

            aspect_results.append({
                "aspect": aspect_name,
                "sentiment": sentiment,
                "confidence": round(aspect_conf, 3),
                "evidence": evidence,
                "staff_category": staff_category,
                "department": department,
            })
            clause_results.append({
                "text": evidence,
                "aspect": aspect_name,
                "sentiment": sentiment,
            })

        _t_sent = time.perf_counter() - _t0

        routing = self.router.route(aspect_results)

        if not aspect_results:
            em_results = self.theme_discoverer.discover([text]) if self.theme_discoverer.is_trained else []
            emerging_theme = em_results[0]["theme"] if em_results and em_results[0]["theme"] else ""
            # known_category_match is True only when we successfully
            # matched the feedback to a known category (aspects OR theme).
            # If neither fired, this is an unknown anomaly.
            known_match = bool(emerging_theme)
        else:
            emerging_theme = ""
            known_match = True

        _t_total = time.perf_counter() - _t0
        self._timing_totals["calls"] += 1
        self._timing_totals["sl"] += _t_sl
        self._timing_totals["clause"] += _t_clause - _t_sl
        self._timing_totals["aspect"] += _t_aspect - _t_clause
        self._timing_totals["sent"] += _t_sent - _t_aspect
        self._timing_totals["total"] += _t_total

        if self._print_every and self._timing_totals["calls"] % self._print_every == 0:
            n = self._timing_totals["calls"]
            print(f"\n[Pipeline] timing after {n} calls (avg ms): "
                  f"sl={self._timing_totals['sl']/n*1000:.1f} "
                  f"clause={self._timing_totals['clause']/n*1000:.1f} "
                  f"aspect={self._timing_totals['aspect']/n*1000:.1f} "
                  f"sent={self._timing_totals['sent']/n*1000:.1f} "
                  f"total={self._timing_totals['total']/n*1000:.1f}", flush=True)

        return {
            "feedback_id": feedback_id,
            "source": source,
            "raw_text": raw_text,
            "service_line": service_line,
            "service_confidence": service_confidence,
            "aspects": aspect_results,
            "clauses": clause_results,
            "routing": routing,
            "known_category_match": known_match,
            "emerging_theme": emerging_theme,
        }


def demo_inference(pipeline):
    samples = [
        ("The doctor explained everything well, but the reception staff was rude "
         "and we waited almost 2 hours for billing after discharge.",
         "Google Review", "FB-DEMO-001"),
        ("Nurses were very caring after my surgery, but discharge took too long.",
         "Post-discharge Survey", "FB-DEMO-002"),
        ("The hospital app kept crashing and I could not download my report.",
         "App Feedback", "FB-DEMO-003"),
    ]
    for text, source, fid in samples:
        result = pipeline.analyze(text, source=source, feedback_id=fid)
        print(f"\n--- Feedback: {fid} ---")
        print(f"  Service Line: {result['service_line']} (conf={result['service_confidence']})")
        for a in result["aspects"]:
            print(f"  - {a['aspect']}: {a['sentiment']} | dept={a['department']}", end="")
            if a.get("staff_category"):
                print(f" staff={a['staff_category']}", end="")
            print()
        print(f"  Routing: {result['routing']}")