import re

class TextNormalizer:
    def __init__(self):
        self.typos = {
            "inconveinece": "inconvenience",
            "inconvienence": "inconvenience"
        }

    def normalize(self, text: str) -> str:
        if not text or not isinstance(text, str):
            return ""
        text = text.strip()
        for typo, fix in self.typos.items():
            text = re.sub(r'\b' + typo + r'\b', fix, text, flags=re.IGNORECASE)
        text = re.sub(r"\s+", " ", text)
        return text
