import numpy as np
import joblib
from typing import Dict, List, Any
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

from src.embeddings.embedding_cache import EmbeddingCache
from src.aspect_detection.keyword_gate import ASPECT_KEYWORDS

import spacy as _spacy

_NLP = None

def get_nlp():
    global _NLP
    if _NLP is None:
        try:
            _NLP = _spacy.load("en_core_web_sm")
        except OSError:
            print("[Warning] spaCy model 'en_core_web_sm' not found. Dependency-parse fallback is disabled.")
            _NLP = False
    return _NLP

POSITIVE_KEYWORDS = [
    "good", "great", "excellent", "amazing", "wonderful", "helpful", "kind",
    "caring", "polite", "professional", "attentive", "friendly", "prompt",
    "quick", "fast", "satisfied", "happy", "pleased", "clean", "comfortable",
    "recommend", "appreciate", "thank", "best", "love", "nice", "clear",
    "explained", "thorough", "supportive", "responsive", "gentle", "patient",
    "well", "easy", "smooth",
]

NEGATIVE_KEYWORDS = [
    "rude", "bad", "terrible", "horrible", "awful", "delayed", "slow",
    "late", "unacceptable", "frustrated", "angry", "ignored", "problem",
    "issue", "complaint", "dirty", "unclean", "pain", "hurt", "worst",
    "hate", "poor", "disappointed", "careless", "arrogant", "shouted",
    "rushed", "negligence", "wrong", "harm", "emergency", "waited", "wait",
    "long", "no one", "nobody", "didn't", "couldn't", "wouldn't", "not",
    "critical", "inconvenience", "inconvenient", "ignorance", "ignorant",
]

import re
_POS_REGEX = re.compile(r"\b(?:" + "|".join(map(re.escape, POSITIVE_KEYWORDS)) + r")\b", re.IGNORECASE)
_NEG_REGEX = re.compile(r"\b(?:" + "|".join(map(re.escape, NEGATIVE_KEYWORDS)) + r")\b", re.IGNORECASE)


class SentimentAnalyzer:
    def __init__(self, embedding_cache: EmbeddingCache, confidence_threshold: float = 0.60):
        self.cache = embedding_cache
        self.confidence_threshold = confidence_threshold
        self.model = LogisticRegression(
            max_iter=1000, C=1.0,
            class_weight="balanced", random_state=42, n_jobs=-1,
        )
        self.encoder = LabelEncoder()
        self.is_trained = False

    def _spacy_dependency_sentiment(self, spacy_doc, aspect: str) -> Dict[str, Any]:
        if not spacy_doc or spacy_doc is False:
            return None
            
        candidate_kws = ASPECT_KEYWORDS.get(aspect, [])
        if not candidate_kws:
            return None
            
        aspect_tokens = []
        for token in spacy_doc:
            if any(kw in token.text.lower() or kw in token.lemma_.lower() for kw in candidate_kws):
                aspect_tokens.append(token)
                
        if not aspect_tokens:
            return None
            
        INTENSIFIERS = {"very", "really", "extremely", "highly", "incredibly", "completely", "so"}
        DIMINISHERS = {"slightly", "somewhat", "a bit", "kind of", "barely", "hardly"}
        NEGATIONS = {"not", "never", "no", "n't"}
        
        def check_modifiers(token):
            is_negated = False
            multiplier = 1.0
            
            for child in token.children:
                lower_text = child.text.lower()
                # Check formal negation dependency or explicit negation word
                if child.dep_ == "neg" or lower_text in NEGATIONS:
                    is_negated = True
                
                # Check for intensifiers/diminishers
                if child.dep_ in ("advmod", "amod"):
                    if lower_text in INTENSIFIERS:
                        multiplier = 1.2
                    elif lower_text in DIMINISHERS:
                        multiplier = 0.70
            return is_negated, multiplier

        for t in aspect_tokens:
            neighborhood = [(t, 0)]
            for child in t.children:
                neighborhood.append((child, abs(t.i - child.i)))
            if t.head and t.head != t:
                neighborhood.append((t.head, abs(t.i - t.head.i)))
                for child in t.head.children:
                    if child != t:
                        neighborhood.append((child, abs(t.i - child.i)))
            
            # --- Passive Voice Handling ---
            if t.dep_ in ("pobj", "nsubjpass", "dobj"):
                # Trace ancestors to find governing VERB
                for anc in t.ancestors:
                    if anc.pos_ == "VERB":
                        # Verify it's a passive verb (has auxpass child)
                        is_passive = False
                        for c in anc.children:
                            if c.dep_ == "auxpass":
                                is_passive = True
                                break
                        if is_passive and anc not in [node[0] for node in neighborhood]:
                            neighborhood.append((anc, abs(t.i - anc.i)))
                        break
            
            # Extract actual tokens and append modifier conjuncts
            final_neighborhood = []
            seen = set()
            for node, dist in neighborhood:
                if node not in seen:
                    final_neighborhood.append((node, dist))
                    seen.add(node)
                    # Adjective conjunctions (e.g. polite and good)
                    if node.pos_ in ("ADJ", "VERB"):
                        for conj in node.conjuncts:
                            if conj not in seen:
                                final_neighborhood.append((conj, abs(t.i - conj.i)))
                                seen.add(conj)

            # Sort by distance
            final_neighborhood.sort(key=lambda x: x[1])
            
            for rel, _ in final_neighborhood:
                is_negated, multiplier = check_modifiers(rel)
                
                rel_text = rel.text.lower()
                rel_lemma = rel.lemma_.lower()
                
                pos_match = bool(_POS_REGEX.search(rel_text)) or bool(_POS_REGEX.search(rel_lemma))
                neg_match = bool(_NEG_REGEX.search(rel_text)) or bool(_NEG_REGEX.search(rel_lemma))
                
                if pos_match and not neg_match:
                    sentiment = "negative" if is_negated else "positive"
                    conf = min(0.99, 0.85 * multiplier)
                    return {"sentiment": sentiment, "confidence": round(conf, 3), "method": "dep_parse"}
                elif neg_match and not pos_match:
                    sentiment = "positive" if is_negated else "negative"
                    conf = min(0.99, 0.85 * multiplier)
                    return {"sentiment": sentiment, "confidence": round(conf, 3), "method": "dep_parse"}
        
        return None

    def _keyword_score(self, text: str) -> Dict[str, float]:
        pos_count = len(_POS_REGEX.findall(text))
        neg_count = len(_NEG_REGEX.findall(text))
        return {"positive": pos_count, "negative": neg_count}

    def train(self, texts: List[str], sentiments: List[str], test_size: float = 0.2):
        # Deduplicate by text to avoid leakage
        seen = {}
        for t, l in zip(texts, sentiments):
            if t not in seen:
                seen[t] = l
        unique_texts = list(seen.keys())
        unique_labels = list(seen.values())
        print(f"[SentimentAnalyzer] Unique texts: {len(unique_texts)} (from {len(texts)} samples)")

        X = self.cache.encode_and_store(unique_texts)
        y = self.encoder.fit_transform(unique_labels)

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y,
        )

        self.model.fit(X_train, y_train)
        self.is_trained = True

        y_pred = self.model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        print(f"\n[SentimentAnalyzer] Accuracy (LR, unique-text split): {acc:.4f}")
        print(classification_report(
            y_test, y_pred,
            target_names=self.encoder.classes_,
            zero_division=0,
        ))

    def predict(self, text: str, aspect: str = None) -> Dict:
        if not self.is_trained:
            kw = self._keyword_score(text)
            return {"sentiment": "positive" if kw["positive"] > kw["negative"] else "negative", "confidence": 0.5}

        embedding = self.cache.encode(text).flatten()
        return self.predict_with_embedding(embedding, text, aspect)

    def predict_with_embedding(self, embedding: np.ndarray, text: str, aspect: str = None, spacy_doc=None) -> Dict:
        """Predict sentiment from a pre-computed embedding.

        The caller must supply the original `text` so the keyword-override
        path remains operational (same behavior as predict()).
        """
        if not self.is_trained:
            kw = self._keyword_score(text)
            return {"sentiment": "positive" if kw["positive"] > kw["negative"] else "negative", "confidence": 0.5}

        # Targeted aspect override via grammatical dependency tree
        if aspect and spacy_doc:
            dep_res = self._spacy_dependency_sentiment(spacy_doc, aspect)
            if dep_res:
                return dep_res

        probas = self.model.predict_proba(embedding.reshape(1, -1))[0]
        classes = self.encoder.classes_

        # ML prediction
        ml_idx = int(np.argmax(probas))
        ml_sentiment = classes[ml_idx]
        ml_conf = float(probas[ml_idx])

        # Keyword adjustment
        kw = self._keyword_score(text)
        pos_kw, neg_kw = kw["positive"], kw["negative"]
        kw_diff = pos_kw - neg_kw

        # If keywords strongly disagree with ML, override
        if kw_diff >= 2 and ml_sentiment != "positive":
            return {"sentiment": "positive", "confidence": 0.70, "method": "kw_override"}
        if kw_diff <= -1 and ml_sentiment != "negative":
            return {"sentiment": "negative", "confidence": 0.70, "method": "kw_override"}

        if ml_conf >= self.confidence_threshold or ml_conf >= 0.40:
            return {"sentiment": ml_sentiment, "confidence": round(ml_conf, 3), "method": "ml"}

        return {"sentiment": "neutral", "confidence": round(ml_conf, 3), "method": "default_neutral"}

    def save(self, path: str):
        joblib.dump({"model": self.model, "encoder": self.encoder}, path)

    def load(self, path: str):
        data = joblib.load(path)
        self.model = data["model"]
        self.encoder = data["encoder"]
        self.is_trained = True