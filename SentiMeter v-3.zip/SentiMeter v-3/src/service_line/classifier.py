import numpy as np
import joblib
from typing import Dict, List
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

from src.embeddings.embedding_cache import EmbeddingCache


SERVICE_LINES = [
    "OPD", "Inpatient", "Surgery", "Diagnostics",
    "Pharmacy", "Billing / Insurance", "Facilities",
    "Emergency", "Digital / Communication",
]

SERVICE_LINE_KEYWORDS = {
    "OPD": ["appointment", "opd", "outpatient", "clinic", "registration", "queue", "walk-in"],
    "Inpatient": ["inpatient", "ipd", "ward", "admission", "room", "stay", "rounds", "bed", "discharge"],
    "Surgery": ["surgery", "surgical", "operation", "ot", "pre-op", "post-op", "surgeon"],
    "Diagnostics": ["lab", "test", "scan", "mri", "x-ray", "ultrasound", "blood", "report", "result"],
    "Pharmacy": ["pharmacy", "medicine", "medication", "drug", "prescription", "pharmacist"],
    "Billing / Insurance": ["bill", "billing", "charge", "insurance", "payment", "estimate", "cashier"],
    "Facilities": ["parking", "cleanliness", "food", "lift", "washroom", "cafeteria", "dirty"],
    "Emergency": ["emergency", "er", "casualty", "urgent", "trauma", "accident"],
    "Digital / Communication": ["app", "portal", "website", "online", "digital", "sms", "phone"],
}


class ServiceLineClassifier:
    def __init__(self, embedding_cache: EmbeddingCache, confidence_threshold: float = 0.55):
        self.cache = embedding_cache
        self.confidence_threshold = confidence_threshold
        self.model = OneVsRestClassifier(LogisticRegression(
            max_iter=1000, C=1.0,
            class_weight="balanced", random_state=42, n_jobs=-1,
        ))
        self.encoder = MultiLabelBinarizer(classes=SERVICE_LINES)
        self.is_trained = False

    def _rule_based(self, text: str) -> Dict:
        lower = text.lower()
        scores = {}
        for service, keywords in SERVICE_LINE_KEYWORDS.items():
            scores[service] = sum(1 for kw in keywords if kw in lower)

        # Add any service line that has at least 1 keyword matched
        matched = [svc for svc, c in scores.items() if c > 0]
        if not matched:
            return {"service_line": "OPD", "service_confidence": 0.50, "method": "fallback"}

        best_service = max(scores, key=scores.get)
        best_count = scores[best_service]
        
        return {
            "service_line": ", ".join(matched),
            "service_confidence": round(0.70 + min(best_count * 0.05, 0.20), 3),
            "method": "rule",
        }

    def train(self, texts: List[str], labels: List[str], test_size: float = 0.2):
        seen = {}
        for t, l in zip(texts, labels):
            if t not in seen:
                seen[t] = l
        unique_texts = list(seen.keys())
        unique_labels = [[list(seen.values())[i]] for i in range(len(seen))]
        print(f"[ServiceLineClassifier] Unique texts: {len(unique_texts)} (from {len(texts)} rows)")

        X = self.cache.encode_and_store(unique_texts)
        y = self.encoder.fit_transform(unique_labels)

        # Ensure y has classes
        if y.shape[1] == 0:
            y = self.encoder.fit_transform([SERVICE_LINES])

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42,
        )

        self.model.fit(X_train, y_train)
        self.is_trained = True

        y_pred = self.model.predict(X_test)
        
        # Calculate strict exact match accuracy
        acc = accuracy_score(y_test, y_pred)
        print(f"\n[ServiceLineClassifier] Exact Match Accuracy (LR, unique-text split): {acc:.4f}")
        print(classification_report(
            y_test, y_pred,
            target_names=self.encoder.classes_,
            zero_division=0,
        ))

    def predict(self, text: str) -> Dict:
        """Standard text-in / dict-out prediction. Internally encodes once."""
        if not self.is_trained:
            return self._rule_based(text)

        embedding = self.cache.encode(text).flatten()
        return self.predict_with_embedding(embedding, text)

    def predict_with_embedding(self, embedding: np.ndarray, text: str) -> Dict:
        """Predict service line from a pre-computed embedding.

        `text` is required for the medium-confidence keyword-boost path and
        for the low-confidence rule-based fallback. The caller MUST supply
        the original text — that's how the embedding was produced.
        """
        if not self.is_trained:
            return self._rule_based(text)

        # Multi-label probability extraction
        probas = self.model.predict_proba(embedding.reshape(1, -1))[0]
        classes = self.encoder.classes_

        import re
        lower = text.lower()
        kw_scores = {}
        for service, keywords in SERVICE_LINE_KEYWORDS.items():
            if service in classes:
                score = sum(1 for kw in keywords if re.search(r'\b' + re.escape(kw) + r'\b', lower))
                kw_scores[service] = score

        # Always boost probabilities with keywords to properly catch multi-intents
        if kw_scores:
            max_kw = float(max(kw_scores.values()) if kw_scores else 0)
            if max_kw > 0:
                for i, service in enumerate(classes):
                    if service in kw_scores:
                        probas[i] += (kw_scores[service] / max_kw) * 0.20
                        probas[i] = min(probas[i], 1.0)

        ml_matched = []
        best_conf = 0.0
        
        for cls, prob in zip(classes, probas):
            if prob > best_conf:
                best_conf = float(prob)
            # Include if ML confidence is strong (>=0.30) OR if it explicitly hit a keyword
            if prob >= 0.30 or kw_scores.get(cls, 0) > 0:
                if cls not in ml_matched:
                    ml_matched.append(cls)

        if ml_matched:
            return {
                "service_line": ", ".join(ml_matched),
                "service_confidence": round(best_conf, 3),
                "method": "ml+k" if sum(kw_scores.values()) > 0 else "ml",
            }

        # Low confidence: pure rule-based fallback.
        return self._rule_based(text)

    def save(self, path: str):
        joblib.dump({"model": self.model, "encoder": self.encoder}, path)

    def load(self, path: str):
        data = joblib.load(path)
        self.model = data["model"]
        self.encoder = data["encoder"]
        self.is_trained = True